Action()
{

	web_reg_find("Text=Log On to IBM Cognos Software", 
		LAST);

	web_url("cognos.cgi", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../ps/login/images/login_icon.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/login/images/login_ibm_logo.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/login/images/login_header.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	lr_start_transaction("Login");

	web_reg_find("Text=IBM Cognos Software", 
		LAST);

	web_submit_form("cognos.cgi_2", 
		"Snapshot=t2.inf", 
		ITEMDATA, 
		"Name=CAMUsername", "Value=GM51516", ENDITEM, 
		"Name=CAMPassword", "Value=GM&51436291", ENDITEM, 
		LAST);

	web_reg_find("Text=Public Folders - \n\t\t\t\t\t\t\tIBM Cognos Connection", 
		LAST);

	web_url("cognos.cgi_3", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../skins/corporate/shared/banner.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/portal/images/action_search_ani.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/your_logo_here.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/tool_sep_dot_line_banner.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/ibm-logo-white.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/portal/images/action_paste.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/toolbar_divider.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/portal/images/action_go_ani.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/action_scroll_right_disabled.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/action_scroll_left_disabled.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/portal/images/checkmark.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/tools_dashboard.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/tools_query_studio.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_start_transaction("ClkonFolder");

	web_reg_find("Text=Public Folders - \n\t\t\t\t\t\t\tIBM Cognos Connection", 
		LAST);

	lr_think_time(25);

	web_link("Maintenance", 
		"Text=Maintenance", 
		"Snapshot=t4.inf", 
		LAST);

	lr_end_transaction("ClkonFolder",LR_AUTO);

	lr_start_transaction("ClkonReport");

	web_reg_find("Text=BIMIO 1002 - All Open Maintenance Workorders - Network - IBM Cognos Viewer", 
		LAST);

	lr_think_time(11);

	web_link("BIMIO 1002 - All Open Maintenance Workorders - Network", 
		"Text=BIMIO 1002 - All Open Maintenance Workorders - Network", 
		"Snapshot=t5.inf", 
		EXTRARES, 
		"Url=../schemas/GlobalReportStyles_10.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../prompting/res/promptingStrings_en.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../prompting/properties.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../prompting/reportskin/prompting/promptCommon.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../prompting/res/promptLocale_en.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../prompting/res/promptLocale_en-gb.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/prompting/images/icon_tree_I.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/viewer/QSRVCommon.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/prompting/images/blank.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/prompting/images/icon_tree_L.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../reportstyles/images/button_bg.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../reportstyles/images/prompt_footer_bg.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../reportstyles/images/button_disabled_bg.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/dis_action_drill_up.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/action_keep_report.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/dis_action_drill_down.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/action_run.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/action_go_to.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/action_add_report.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/portal/images/dropdown_arrow_narrow.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/action_view_html.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../common/images/spacer.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/action_return.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../reportstyles/images/button_hover_bg.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/progress.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonReport",LR_AUTO);

	lr_start_transaction("ClkonFinish");

	web_custom_request("cognos.cgi_4", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"Body=_promptControl=prompt&b_action=cognosViewer&cv.actionState="
		"H4sIAAAAAAAAALVUW2-aMBT*K3ka2wMxCeESLWQDAlKktiAY3UNVRcY5ZW4TO7Id6P79nHhMhId0nbSnxOec73znHpDjlCjK2VZhBWEg8RHS*h*FwRMX*ZJClsowoAryMGA4h7Ck9h6Tl93mJkC1IDjirIQQ0X1O*IFxiciBdveUIfO09fPLPsE10eRVSVuU7APOi8-5pOBC4QwRYmu5kSVPPEtBTKgz8-uDUb83dnzf6-WdmdPreXPH8dxBtPB9p2HuTvIu9fujxbA3cJf*yPUifzxeLIf*2BtO*-PIi9xlgEyoATL5XGRFjjbfPwNRaxA5lVKHKpv5wSuQUoElAKeWErpSQoLV4lIXyri8qhPhTAFTyAT*8LVSTjq3mFZizAh0HpGAqjJn3Sy*jVeWTt*1utY0y6xVAcy6QFjfuXjhQruT2uIO1Em-O4-twRWC5lj8NAPQjFE3qAVrKqFBa8Hz4io9JUpo58XvJixqnhXbQG33DrocFE"
		"6xwjGrphlXxLtNfNWQjDLAB9jFWxBHStr86TGhaROe3G2Tttj1rmjnMyzhr*bASdYGIfUY-AafdX*6bEU6J9089VaPq2*T9t9mqYVlfp88yzhqspwoS-nJ5lrZXp7zXWjCzeG4p3AC0dZdnkK2xurHf6ksqt0-ZFiqj5-eqLNZ9Lm2vboaZpHblokRnlJ2aMJ235bd8TUKXV5k1DzdvwBAKePGygUAAA__&cv.catchLogOnFault=true&cv.id=_NS_&cv.objectPermissions=execute%20read%20traverse%20&cv.responseFormat=data&cv.showFaultPage=true&errURL="
		"%2Fibmcognos%2Fcgi-bin%2Fcognos.cgi%3Fb_action%3Dxts.run%26m%3Dportal%2Fcc.xts%26m_folder%3Di1B93573081994031B1004C11425DE991%26m_folder2%3Dm-i937E6052F9724D988EF69846A3CD4D2F&executionParameters="
		"H4sIAAAAAAAAAH2SUW*CMBSFn92vMLxLdb4RJCHTLEs2Z6ZZlphlqXCjTUpLegvIv18BqdVNeYFwz-l6zoVwV2CQU0Uz0KBweMy4wMC8nHkHrfOAkBRK4DIH5SdyLySaW0YwOUBGkeyYkZIp8U7GIzJrrKrKr6a*VHvyOB5PyNfb67q1jZhATUUCxoUs0HUOM2-9Hq9Gi*VTECtF657Xv7XQ08G*GaOkeUtvHgiIRKZM7E0Ui6INatPiL2p*Ul7AdvLtRQ*D9gqZhswJ81dtpYOwGQozcvRHDFArc7oXrTY-83iz*IiXz4uQ9NpLd9kQ73S-UyBr07yYuG7*-xsgy3IOK9fkOLooTCS8QFZetdlJyYEKL9KqgK6GVV4jUoY5p-WNdSgomSxwOKd1xznJrykF3lhonfZOI3EKk6bxea-ELtZ*VFfRzc8-evQLJ8*yc-kCAAA_&m_tracking="
		"H4sIAAAAAAAAAHWRsW6DMBCG5-YpKvZiMEQqiLC4S6UyZelK4AKOwCbcBcPb14mriFbUiyXf9-1nn7PjFdNKqwlGLElqJbQimOll7juFqa3uvZZoSBmrYYJODzD6lW6URrv1DKsW*hLZUVqURcz7EWeUD9EY45vI12PDeBCE7Kv4PNy1V6mQSlWBtVCmtAyw9-65kJc-P91WdquXp5NUkpYDjaAaalf6jKlUlt4FQZCxLXgdJOvfKtIoVePlSSHimF8uMediOndmwvNbUsSFESLmRVcbYYpkmVrXQdbrTKVr*HjfzuU7ZzhmbQ2jrgDxr3h-Cw*jMHbiA1u7doh0xe2O9pOGDgic7kjnupONUeff1u57*xUCAAA_&run.prompt=false&ui.action=forward&ui.backURL="
		"%2Fibmcognos%2Fcgi-bin%2Fcognos.cgi%3Fb_action%3Dxts.run%26m%3Dportal%2Fcc.xts%26m_folder%3Di1B93573081994031B1004C11425DE991%26m_folder2%3Dm-i937E6052F9724D988EF69846A3CD4D2F&ui.cafcontextid=CAFW000000a0Q0FGQTYwMDAwMDAwMDlBaFFBQUFDRTVPQk1CRUhrUG1ud24tN3Mzc1h3OXktMWNBY0FBQUJUU0VFdE1qVTJJQUFBQUxEZGdqcjF3Q1lEQkwtWGl2QSpFc1ZRZ3Z0SDdXdzVIRzZPRUx0TXh4TmU0MjM2NjB8cnY_&ui.conversation="
		"H4sIAAAAAAAAANVZW1fiyhJ*nvMr3J619zywxlzJxT0z68SQSEQuAoIya5ark3QgkHRCugOEX787BBhw1FF0POfwoNhdVf1VdVV1VfnZTvFpnPghSLI2nKYQk6NFGCB8Sje*HI8IiU8ZxoUzGEQxTE6caIgiTH*FDHZGMASYsX1KygjM8Zpxgf0t43w*P5kLJ1EyZHiW5Zib*mVnxfbJR5gA5EDKhf1TksXwy3GOBeAMOaM1lOOv--qQfz7nOwiEcId4gU8xSXw0PP6apOgzsyHZZYnsMXRIC5DRvVMwBIkzyjc6VEIAmyvC46*MEyECEWG8KHBh8u0-ucQvH*vAz5dzvB*-MwmMo4Rs9s6sutU84liWP-p0pAXBUTOG6GiH46gfJZMooeIwpWhAMqd-f-xeIP6BcA93TPwI4R3QnabW*mQ09FMtSUC2MfVmdWvv9Z2c0G0cgXhl*PwLA5ETuVRVektbUSAX1d3apDj0G6d835j9w2efwP"
		"Ce6aixmyvKsygKIEBb4gdvaY-DQGlIbwuSNEHNlMQp6Y8g0mbAD4AdwJ-ucC1yBoL03s3bm7NJkq75VlRb4EyO-Ck1Cj8rcFmI-FqLXYZCkXXY9IFPuqME4hH1mRfo4OenCgeBH0IEE98pwNCYMvLbhS799rQeOzHzVGQ70AZ5JOQRSvAmJuoAgSFMdEB97IcZ-r3aXZDnKp6vUe-cRbyGgpZuuAwzfunafjgOT4Asl2WRkxVeUOUTEIJlhMB8hfBUFViWifnYZTBMZgEkjOvjGBBndHf3x59--nF3VwTpVQqTbLP0jsG9OdJVbWB7CpRsT1J4xxNEoKiOxEOxDCVXdBxJ8UQFiq4n8q4sUwpWsIGiyGVbZiXH3siJgTOhxn*OOtxdqyDGVJs132ZvC-aoAgi1aEJ*QOU5DrKqLdiKo3qSo7Ii69myqMiC7QouL8gCx4mCbdsi59GbUYBadj3FlW0eKhDy7kYOcJwoRfuWV-mywJYVXtos"
		"eFSgWxYcRaHKUjmeYAsKKwkuK4t8GThA8CQeiJBaiQcKB3hOEMoutSRLUfL29rCDomebj4ocRF0RxDgNQL704mwW-SzjJaHwAHshF0XosMS2xddZRXrxXhymlRklIXh2ZN9-oh56Z7YJ6Bv345X5WY*dPFXt1i-NBAxD6un7yn94nXkaVKFeznuYhRY4aIGEkhEa*m9poo2kFbZv8lNm2iPdoftV7td7Rb3Tht4DyB9-sTb8cx*50fwk0nsPXMH9S3g72HNot6PoIX-8NWTGt8PihXtXyHqvo7*VrTv6u0K-xlCvaF2tQ8HnxehB6B8pz36jwVd33PPhHCZW5SDMd43OQ*-K78Oc79DixYHWQ*Xj-yBg6hpmGgStJCR6FMZ*AA8D7oEAP8s9Xl3hG*v255AyHxBCS978-dlIeckDv2m8Cll1q268WplnN14P6BLMQYYt5ASpC1t7bf*7dl-bx1RD2XXbOuT1vW5fvgDydlQwO6G8r8N8aO"
		"MbJzRY-r-sXNSBl5HzosL2sDaToqetF3XI4sHcHLpqMvMuDyYmzTSdDFPC13fNzzHI72iXsT9EgKTJS6YdGxAsz4ns6qOIhmiwos6KImeIgiGpJquapmHoFUMvm6wp86ZZlllWLujLgqiIHF8ReKEsSHyxyJq6JMlnRkWVqRxVV3hNMeWKabJl8YyrlHVNNUxd13JhgqIqZ7paYVlBqyisJkis8lA98g5hhGFQlCRnAEPXhCtrPrsEf9uwetbk6B5*6sjEd0BgBDB-VF6CfDUy4tn-jt2BO8snHm7RNR9i78fe*-cAHwTRXEMoIuCxavY94F8CNExpWnhNV54nxucPS39PVw7Rp6H9FkXaXk5*1uUelpRtv*InRdoAwU463lvf5BID5ePol8xyX*Yj69F-MeTfnfvH24nC*47*t*cWQwfu6f8A7FM-*7Za3TvaTxptrXFuvPXAhEIKV2gsCvdpL87JsR-GAWztMv3U-vh5kYz92a8fjy3l"
		"fRH5TDoA2SPmSODMj1J8VAFZIWdNfl9Kih8xaOZuOCnJwb1Tsf-D83b9EcfQ8T2-KMTe1yWL3qWzC*Ab*-2Y2YNHkznMJ9lP-3-hr4D8vSX9a0j*rorY0tYfRui3r24ZUD-TTUaMZ8RyetWhY4Ug7vSvrCmbWEPabLRq3NVgoPjhRXUwbXKyqEqpgUO2NXNRqdFqQoGra2k95TnSadwsHN7XRsuIR-3SyB3X7JKedJZW9VY8i4PRRVmAE0euXbcU-xLcCOf1q-GiwgyXwRXSJJELehfVLHbPsSYNh-MRyy1m07qtD3uuW2sooK3WQErIpRV2mUGbS9vTsW*el0U*6MGprxvp7YJFdVoOTlqRWs2EieSrjQnS5*GEmbVvx4E3Ds7PriqxXFuo9etBR9I1VGNqpN0vBV4TOxecD9A0SL2u44g9YyCwuDme3tSyJVdikyZaatUyjrsxN1sweKQIHDxveeMuOwjLjWDqdbKA3LZU3ChJN82bxS"
		"1sleaas4QGqrmluJlWFozQ7eM0g3HvluU1lVSVtCEApj*ds5XlsC-fys3pbZyeN1okGSas7MCs2RpcMA2P0tfqnaHFEsBPZk0m6dGfwqVe0bNRxxZI0o07hlDqcebQCFrnSS2bStNqvSM3YzNuTY1BdNP3dfFi3L22Qc-LmN4Ati-HQ0NzONLnbCdsAFVads36xJEmCE9B1ZpfLUKrrgzaVUUPm*0LeBVMDQzH11UtMs4M0VreXmRmzU6aqTm41qaWPp6I53zSKYEbzro2Qje71pYuo1t2yWEUZXyhDTUtd0pmzyuLQNwuFY6*js69Tv3rP1ORpKG1HwAA&ui.object=%2Fcontent%2Ffolder%5B%40name%3D'Maintenance'%5D%2Freport%5B%40name%3D'BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network'%5D&"
		"ui.objectClass=report&ui.primaryAction=run", 
		EXTRARES, 
		"Url=../rv/images/action_save_report_view.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/action_send_report.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);

	web_submit_data("cognos.cgi_5", 
		"Action=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=b_action", "Value=cognosViewer", ENDITEM, 
		"Name=cv.actionState", "Value="
		"H4sIAAAAAAAAALVUW2-aMBT*K3ka2wMxCeESLWQDAlKktiAY3UNVRcY5ZW4TO7Id6P79nHhMhId0nbSnxOec73znHpDjlCjK2VZhBWEg8RHS*h*FwRMX*ZJClsowoAryMGA4h7Ck9h6Tl93mJkC1IDjirIQQ0X1O*IFxiciBdveUIfO09fPLPsE10eRVSVuU7APOi8-5pOBC4QwRYmu5kSVPPEtBTKgz8-uDUb83dnzf6-WdmdPreXPH8dxBtPB9p2HuTvIu9fujxbA3cJf*yPUifzxeLIf*2BtO*-PIi9xlgEyoATL5XGRFjjbfPwNRaxA5lVKHKpv5wSuQUoElAKeWErpSQoLV4lIXyri8qhPhTAFTyAT*8LVSTjq3mFZizAh0HpGAqjJn3Sy*jVeWTt*1utY0y6xVAcy6QFjfuXjhQruT2uIO1Em-O4-twRWC5lj8NAPQjFE3qAVrKqFBa8Hz4io9JUpo58XvJixqnhXbQG33DrocFE"
		"6xwjGrphlXxLtNfNWQjDLAB9jFWxBHStr86TGhaROe3G2Tttj1rmjnMyzhr*bASdYGIfUY-AafdX*6bEU6J9089VaPq2*T9t9mqYVlfp88yzhqspwoS-nJ5lrZXp7zXWjCzeG4p3AC0dZdnkK2xurHf6ksqt0-ZFiqj5-eqLNZ9Lm2vboaZpHblokRnlJ2aMJ235bd8TUKXV5k1DzdvwBAKePGygUAAA__", ENDITEM, 
		"Name=cv.catchLogOnFault", "Value=true", ENDITEM, 
		"Name=cv.responseFormat", "Value=data", ENDITEM, 
		"Name=cv.showFaultPage", "Value=true", ENDITEM, 
		"Name=errURL", "Value=/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/cc.xts&m_folder=i1B93573081994031B1004C11425DE991&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Name=m_tracking", "Value=H4sIAAAAAAAAAHWQsW6DMBCG5-YpKvZiMERqEGFxl0r1lKUrAQecwJn4HAxvXyeuIlpRL7Z83-efffnhilmlYBQaSyMVMAVGTOZl6jvAzFV3QWvMkBFSi1F0ahA6rFQDCt3WE6xa0ZdIDtKhJCHBjzihfIjW2tAmodINoVEUky-*ub9rrxLQlFAJZ6HMzDyIXfDPg4Li*em28lu9PB4lSDPvjRbQmHahT5hJcPQmiqKcrMHLIFn-VtFoCU1QbDlLU3q5pJSy8dTZEU9vW55yy1hKeVdbZvl2HlvfQdbLTFC1*Hhfz6Ubb3hmaQ1aVQLxr3j-C42TOPXiA1u6bojmiusdrdJnd-C2B73qb1YmXXwDvZe2ORQCAAA_", ENDITEM, 
		"Name=ui.action", "Value=wait", ENDITEM, 
		"Name=ui.backURL", "Value=/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/cc.xts&m_folder=i1B93573081994031B1004C11425DE991&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Name=ui.primaryAction", "Value=run", ENDITEM, 
		EXTRARES, 
		"Url=cognos.cgi?b_action=rc&rsid=21314&f=MHhhOTI4MjQwOjlNQzQ0MnFxNDIyQ3ZqbHd2c2o4OU00TXdDQzQyTWxkd0N3TTl5dmg_&k=FAAAAITk4EwEQeQ*afCf-uzexfD3L-Vw5dM9lRZG0ega8KXQ-aEtcXsceOQ_&s=FAAAAITk4EwEQeQ*afCf-uzexfD3L-VwrbubKopUQN8b-iSNNelQEtoE*lk_&did=25", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&"
		"ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/viewer/images/top_dis.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=http://10.70.39.5/ibmcognos/images/SGN_logo_Cognos.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/viewer/images/bottom.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/viewer/images/pageup_dis.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/viewer/images/pagedown.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../reportstyles/images/silver_grad.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/viewer/images/tool_sep_dot_line.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonFinish",LR_AUTO);

	lr_think_time(104);

	lr_start_transaction("Logout");

	web_custom_request("cognos.cgi_6", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"Body=b_action=cognosViewer&cv.catchLogOnFault=true&cv.objectPermissions=execute%20read%20traverse%20&cv.responseFormat=successfulRequest&m_tracking="
		"H4sIAAAAAAAAAHWRsW6DMBCG5-YpKvZiMEQqiLC4S6UyZelK4AKOwCbcBcPb14mriFbUiyXf9-1nn7PjFdNKqwlGLElqJbQimOll7juFqa3uvZZoSBmrYYJODzD6lW6URrv1DKsW*hLZUVqURcz7EWeUD9EY45vI12PDeBCE7Kv4PNy1V6mQSlWBtVCmtAyw9-65kJc-P91WdquXp5NUkpYDjaAaalf6jKlUlt4FQZCxLXgdJOvfKtIoVePlSSHimF8uMediOndmwvNbUsSFESLmRVcbYYpkmVrXQdbrTKVr*HjfzuU7ZzhmbQ2jrgDxr3h-Cw*jMHbiA1u7doh0xe2O9pOGDgic7kjnupONUeff1u57*xUCAAA_&ui.action=release&ui.objectClass=report&ui.primaryAction=run", 
		LAST);

	web_reg_find("Text=Log off", 
		LAST);

	web_url("cognos.cgi_7", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/logoff.xts&h_CAM_action=logoff", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	return 0;
}