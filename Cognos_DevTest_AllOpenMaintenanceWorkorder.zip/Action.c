Action()
{
  int i;
  
  web_set_max_html_param_len("1000000");
  
  lr_start_transaction("Cognos_Dev_1002AllOpenMNTNC_Launch");

	web_reg_find("Text=Log On to IBM Cognos Software", 
		LAST);

	

	web_url("cognos.cgi", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../ps/login/images/login_icon.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/login/images/login_ibm_logo.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/login/images/login_header.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");
	
	lr_end_transaction("Cognos_Dev_1002AllOpenMNTNC_Launch", LR_AUTO);

	
	lr_think_time(5);

	lr_start_transaction("Cognos_Dev_1002AllOpenMNTNC_Login");

	web_reg_find("Text=IBM Cognos Software", 
		LAST);

	web_submit_form("cognos.cgi_2", 
		"Snapshot=t2.inf", 
		ITEMDATA, 
		"Name=CAMUsername", "Value=GM51516", ENDITEM, 
		"Name=CAMPassword", "Value=GM&51436291", ENDITEM, 
		LAST);

	web_reg_find("Text=Public Folders - \n\t\t\t\t\t\t\tIBM Cognos Connection", 
		LAST);

	web_url("cognos.cgi_3", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../skins/corporate/shared/banner.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/portal/images/action_search_ani.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/your_logo_here.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/tool_sep_dot_line_banner.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/ibm-logo-white.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/portal/images/action_paste.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/toolbar_divider.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/portal/images/action_go_ani.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/action_scroll_right_disabled.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/action_scroll_left_disabled.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/portal/images/checkmark.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/tools_dashboard.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/tools_query_studio.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);

	lr_end_transaction("Cognos_Dev_1002AllOpenMNTNC_Login",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Cognos_Dev_1002AllOpenMNTNC_ClkonFolder");

	web_reg_find("Text=Public Folders - \n\t\t\t\t\t\t\tIBM Cognos Connection", 
		LAST);


	web_link("Maintenance", 
		"Text=Maintenance", 
		"Snapshot=t4.inf", 
		LAST);

	lr_end_transaction("Cognos_Dev_1002AllOpenMNTNC_ClkonFolder",LR_AUTO);
	
	lr_think_time(5);
	
	/*Correlation comment - Do not change!  Original value='H4sIAAAAAAAAALVUW2-aMBT*K3ka2wMxCeESLWQDAlKktiAY3UNVRcY5ZW4TO7Id6P79nHhMhId0nbSnxOec73znHpDjlCjK2VZhBWEg8RHS*h*FwRMX*ZJClsowoAryMGA4h7Ck9h6Tl93mJkC1IDjirIQQ0X1O*IFxiciBdveUIfO09fPLPsE10eRVSVuU7APOi8-5pOBC4QwRYmu5kSVPPEtBTKgz8-uDUb83dnzf6-WdmdPreXPH8dxBtPB9p2HuTvIu9fujxbA3cJf*yPUifzxeLIf*2BtO*-PIi9xlgEyoATL5XGRFjjbfPwNRaxA5lVKHKpv5wSuQUoElAKeWErpSQoLV4lIXyri8qhPhTAFTyAT*8LVSTjq3mFZizAh0HpGAqjJn3Sy*jVeWTt*1utY0y6xVAcy6QFjfuXjhQruT2uIO1Em-O4-twRWC5lj8NAPQjFE3qAVrKqFBa8Hz4io9JUpo58XvJixqnhXbQG33DrocFE6xwjGrphlXxLtNfNWQjDLAB9jFWxBHStr86TGhaROe3G2Tttj1rmjnMyzhr*bASdYGIfUY-AafdX*6bEU6J9089VaPq2*T9t9mqYVlfp88yzhqspwoS-nJ5lrZXp7zXWjCzeG4p3AC0dZdnkK2xurHf6ksqt0-ZFiqj5-eqLNZ9Lm2vboaZpHblokRnlJ2aMJ235bd8TUKXV5k1DzdvwBAKePGygUAAA__' Name ='cv.actionState' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=cv.actionState",
	    "RegExp=\"cv\\.actionState\":\\ \"(.*?)\",\\ ",
		SEARCH_FILTERS,
     	"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/cognos.cgi*",
    	LAST);
		
		web_reg_save_param("actionstate", "LB=cv.actionState\": \"", "RB=\", \"", LAST);
		web_reg_save_param_regexp(
		"ParamName=sConversation",
		"RegExp=\"m\\_sConversation\":\\ \"(.*?)\",\\ ",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/cognos.cgi*",
		LAST);
		
		//web_reg_save_param("sConversation", "LB=m_sConversation\": ", "RB=\", \"", LAST);
		 web_reg_save_param("CAFContext", "LB=window.oCV_NS_.setCAFContext(", "RB=\");", LAST);
		 
		 web_reg_save_param("executionParameters", "LB=m_sParameters\": \"", "RB=\", \"", LAST);
		 	web_reg_save_param("Tracking", "LB=m_sTracking\": \"", "RB=\", \"", LAST);


	lr_start_transaction("Cognos_Dev_1002AllOpenMNTNC_ClkonReport");

	web_reg_find("Text=BIMIO 1002 - All Open Maintenance Workorders - Network - IBM Cognos Viewer", 
		LAST);

	
	web_link("BIMIO 1002 - All Open Maintenance Workorders - Network", 
		"Text=BIMIO 1002 - All Open Maintenance Workorders - Network", 
		"Snapshot=t5.inf", 
		EXTRARES, 
		"Url=../schemas/GlobalReportStyles_10.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../prompting/res/promptingStrings_en.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../prompting/properties.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../prompting/reportskin/prompting/promptCommon.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../prompting/res/promptLocale_en.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../prompting/res/promptLocale_en-gb.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/prompting/images/icon_tree_I.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/viewer/QSRVCommon.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/prompting/images/blank.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/prompting/images/icon_tree_L.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../reportstyles/images/button_bg.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../reportstyles/images/prompt_footer_bg.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
	"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../reportstyles/images/button_disabled_bg.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/dis_action_drill_up.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/action_keep_report.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/dis_action_drill_down.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
	"Url=../rv/images/action_run.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
	"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/action_go_to.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/action_add_report.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
	"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/portal/images/dropdown_arrow_narrow.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../rv/images/action_view_html.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../common/images/spacer.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/action_return.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../reportstyles/images/button_hover_bg.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/progress.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);

	lr_end_transaction("Cognos_Dev_1002AllOpenMNTNC_ClkonReport",LR_AUTO);
	
	lr_think_time(5);
	
	//web_reg_save_param("var_actionState", "LB=m_sActionState&quot;: &quot;", "RB=&quot;", LAST);
	web_reg_save_param("var_m_tracking", "LB=m_sTracking&quot;: &quot;", "RB=&quot;", LAST);   
    web_reg_save_param("status", "LB=m_sStatus&quot;: &quot;", "RB=&quot;","Ord=All",  LAST);   
	
	lr_start_transaction("Cognos_Dev_1002AllOpenMNTNC_ClkonFinish");
	
	web_custom_request("cognos.cgi_4",
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F",
		"Snapshot=t6.inf",
		"Mode=HTML",
		"Body=_promptControl=prompt&b_action=cognosViewer&cv.actionState=[actionstate]&cv.catchLogOnFault=true&cv.id=_NS_&cv.objectPermissions=execute%20read%20traverse%20&cv.responseFormat=data&cv.showFaultPage=true&errURL=%2Fibmcognos%2Fcgi-bin%2Fcognos.cgi%3Fb_action%3Dxts.run%26m%3Dportal%2Fcc.xts%26m_folder%3Di1B93573081994031B1004C11425DE991%26m_folder2%3Dm-i937E6052F9724D988EF69846A3CD4D2F"
		"&executionParameters=[executionParameters]"
		"&m_tracking=[Tracking]"
		"&run.prompt=false&ui.action=forward&ui.backURL=%2Fibmcognos%2Fcgi-bin%2Fcognos.cgi%3Fb_action%3Dxts.run%26m%3Dportal%2Fcc.xts%26m_folder%3Di1B93573081994031B1004C11425DE991%26m_folder2%3Dm-i937E6052F9724D988EF69846A3CD4D2F"
		"&ui.cafcontextid=[CAFContext]"
		"&ui.conversation=[sConversation]"
		"&ui.object=%2Fcontent%2Ffolder%5B%40name%3D'Maintenance'%5D%2Freport%5B%40name%3D'BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network'%5D&ui.objectClass=report&ui.primaryAction=run",
		EXTRARES,
		"URL=../rv/images/action_save_report_view.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../rv/images/action_send_report.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		LAST);
    
    if ((atoi(lr_eval_string("{currstatus}"))>0))
	{
		do
{
			i++;
    //web_reg_save_param("var_actionState", "LB=m_sActionState&quot;: &quot;", "RB=&quot;", LAST);
	web_reg_save_param("var_m_tracking", "LB=m_sTracking&quot;: &quot;", "RB=&quot;", LAST);   
    web_reg_save_param("status", "LB=m_sStatus&quot;: &quot;", "RB=&quot;","Ord=All",  LAST);   
    web_reg_find("Text=stillWorking", "SaveCount=currstatus", "Search=All", LAST);


	web_submit_data("cognos.cgi_5",
		"Action=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi",
		"Method=POST",
		"RecContentType=text/plain",
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F",
		"Snapshot=t7.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=b_action", "Value=cognosViewer", ENDITEM,
		"Name=cv.actionState", "Value=[cv.actionState]", ENDITEM,
		"Name=cv.catchLogOnFault", "Value=true", ENDITEM,
		"Name=cv.responseFormat", "Value=data", ENDITEM,
		"Name=cv.showFaultPage", "Value=true", ENDITEM,
		"Name=errURL", "Value=/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/cc.xts&m_folder=i1B93573081994031B1004C11425DE991&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"Name=m_tracking", "Value=[var_m_tracking]", ENDITEM,
		"Name=ui.action", "Value=wait", ENDITEM,
		"Name=ui.backURL", "Value=/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/cc.xts&m_folder=i1B93573081994031B1004C11425DE991&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"Name=ui.primaryAction", "Value=run", ENDITEM,
		EXTRARES,
		"URL=cognos.cgi?b_action=rc&rsid=21314&f=MHhhOTI4MjQwOjlNQzQ0MnFxNDIyQ3ZqbHd2c2o4OU00TXdDQzQyTWxkd0N3TTl5dmg_&k=FAAAAITk4EwEQeQ*afCf-uzexfD3L-Vw5dM9lRZG0ega8KXQ-aEtcXsceOQ_&s=FAAAAITk4EwEQeQ*afCf-uzexfD3L-VwrbubKopUQN8b-iSNNelQEtoE*lk_&did=25", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/viewer/images/top_dis.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=http://10.70.39.5/ibmcognos/images/SGN_logo_Cognos.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/viewer/images/bottom.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/viewer/images/pageup_dis.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/viewer/images/pagedown.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../reportstyles/images/silver_grad.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/viewer/images/tool_sep_dot_line.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		LAST);
    
    }	
		while(atoi(lr_eval_string("{currstatus}"))==1);

	}

	lr_end_transaction("Cognos_Dev_1002AllOpenMNTNC_ClkonFinish",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("Cognos_Dev_1002AllOpenMNTNC_Logout");

	web_custom_request("cognos.cgi_6", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/xml", 
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"Body=b_action=cognosViewer&cv.catchLogOnFault=true&cv.objectPermissions=execute%20read%20traverse%20&cv.responseFormat=successfulRequest&m_tracking="
		"H4sIAAAAAAAAAHWRsW6DMBCG5-YpKvZiMEQqiLC4S6UyZelK4AKOwCbcBcPb14mriFbUiyXf9-1nn7PjFdNKqwlGLElqJbQimOll7juFqa3uvZZoSBmrYYJODzD6lW6URrv1DKsW*hLZUVqURcz7EWeUD9EY45vI12PDeBCE7Kv4PNy1V6mQSlWBtVCmtAyw9-65kJc-P91WdquXp5NUkpYDjaAaalf6jKlUlt4FQZCxLXgdJOvfKtIoVePlSSHimF8uMediOndmwvNbUsSFESLmRVcbYYpkmVrXQdbrTKVr*HjfzuU7ZzhmbQ2jrgDxr3h-Cw*jMHbiA1u7doh0xe2O9pOGDgic7kjnupONUeff1u57*xUCAAA_&ui.action=release&ui.objectClass=report&ui.primaryAction=run", 
		LAST);

	web_reg_find("Text=Log off", 
		LAST);

	web_url("cognos.cgi_7", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/logoff.xts&h_CAM_action=logoff", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Maintenance%27%5d%2freport%5b%40name%3d%27BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network%27%5d&ui.name=BIMIO%201002%20-%20All%20Open%20Maintenance%20Workorders%20-%20Network&run.outputFormat=&run.prompt=true&ui.backURL="
		"%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3di1B93573081994031B1004C11425DE991%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Cognos_Dev_1002AllOpenMNTNC_Logout",LR_AUTO);
	
	lr_think_time(5);

	return 0;
}