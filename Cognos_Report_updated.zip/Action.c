Action()
{
	int i;
	web_set_max_html_param_len("2000000");
	
	lr_start_transaction("Cognos_DevCloud_T01_AppLaunch");

	web_set_user("SCOTIA.SGNGROUP.NET\\GM51516", 
		"GM&51436291", 
		"10.184.11.70:80");





	web_url("cognos.cgi", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../ps/login/images/login_header.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/login/images/login_ibm_logo.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/login/images/login_icon.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");
	
	lr_end_transaction("Cognos_DevCloud_T01_AppLaunch", LR_AUTO);
	
	lr_think_time(5);
	lr_start_transaction("Cognos_DevCloud_T02_Login");



	web_reg_find("Text=IBM Cognos Software", 
		LAST);



	web_submit_form("cognos.cgi_2", 
		"Snapshot=t2.inf", 
		ITEMDATA, 
		"Name=CAMUsername", "Value=GM51516", ENDITEM, 
		"Name=CAMPassword", "Value=GM&51436291", ENDITEM, 
		LAST);

	
	//web_reg_save_param("actionstate", "LB=cv.actionState\": \"", "RB=\", \"", LAST);
	
	
	
	
//	var g_PS_PFRootId = "i64C1B8968BDC4C70B18C3DC1286D7E20";
		//	var g_PS_MFRootId = "iDD1CF89BDAFF444890103A45346E0863";
			
			
			
		//web_reg_save_param("g_PS_PFRootId", "LB=var g_PS_PFRootId\= \"", "RB=\";", LAST);

	web_url("cognos.cgi_3", 
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../skins/corporate/shared/banner.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/portal/images/action_search_ani.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/ibm-logo-white.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/tool_sep_dot_line_banner.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/your_logo_here.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/portal/images/action_paste.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/toolbar_divider.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/portal/images/action_go_ani.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/portal/images/checkmark.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/action_scroll_right_disabled.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/shared/images/action_scroll_left_disabled.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/tools_dashboard.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../skins/corporate/branding/tools_query_studio.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);
		
		lr_end_transaction("Cognos_DevCloud_T02_Login", LR_AUTO);
		
		lr_think_time(5);


	lr_start_transaction("Cognos_DevCloud_T03_ClkonFolder");
	
	//web_reg_save_param("g_PS_PFRootId", "LB=var g_PS_PFRootId\= \"", "RB=\";", LAST);

	web_reg_find("Text=Public Folders - \n\t\t\t\t\t\t\tIBM Cognos Connection", 
		LAST);

	lr_think_time(12);

	web_link("Emergency/Repair", 
		"Text=Emergency/Repair", 
		"Snapshot=t4.inf", 
		LAST);

	
	
	lr_end_transaction("Cognos_DevCloud_T03_ClkonFolder", LR_AUTO);
	
	lr_think_time(5);

	
	//"m_sActionState": "CAFS60000002e8AhQAAACE5OBMBEHkPmnwn-7s3sXw9y-1cAcAAABTSEEtMjU2IAAAAEeu9SrKHxzjlnYKPVm24Kb46CWae2qVeOLDP1nqq0jBH4sIAAAAAAAAALVUTXObMBD9K5zq9mCEP4EpprWN6ZBpa49dp4dMhhFi4ygBiZGEnfz7Cqhngg*kPvQEkvbt23374ZHjnCjK2U5hBb4n8RHS*h-53gMXeUghS6XvUQW57zGcg19SM8Hkeb-97qH6wjvirAQf0SQn-MC4RORA*wllqDma*vgliXFNNHtR0hQl*4Dz4nM*K7hQOEOEmPq*uYsfeJaCmNGFHQbW0rbDueWMg2C0mFjWJJyMxlPbdYPQaZkPZ3mfuiN7NbUmw9C1h*PAdZxVOHWd8XQ*WgbjYBh6qAnVQ00*b7IiR5MnT0DUBkROpdShynZ*8AKkVGAIwKmhhFZKSDA6XGqhGpcXOhHOFDCFmsDvvlaPs94qB3EARl7RFgpMRe8eCajkORssoh-R2hhY1sDoG2v1CMIISkVBGsiYK*0xNb5haawkwQUYNzyRvfvu6ApBcyxemw5oB6kr1IFtpNCgjeB5cZGfEiV08*KrCYuaZ822UNtdQZeDwilWOGJVO*OKeL*NLiqSUQb4APtoB*JISZc-3Sc0bcPjn7u4K3Y9LNr5Akv4p0YYxJsGoeuH-oLPb7*5eOYirUqvc9LFU*-VuPq2aa-vow6G5W38JKOgzXCiLOUnk*vHbmnOS6ENb7bGLYUTiK7K8hSyDVaP-0VVVLu-y7BUHz*9o3Ez5Utte7EymgHuGiRGeErZoQ3b-wr7ziUKvV3HqL23-wDSniCdxwUAAA__",

	web_reg_save_param("actionstate", "LB=cv.actionState\": \"", "RB=\", \"", LAST);
	



/*Correlation comment - Do not change!  Original value='CAFS60000002e8AhQAAACE5OBMBEHkPmnwn-7s3sXw9y-1cAcAAABTSEEtMjU2IAAAAA*nUuRKP6uREvGCt3INh4-seiIlLQq-DaH-KdLq4JEmH4sIAAAAAAAAALVUTXObMBD9K5zq9mCEP4EpprWN6ZBpa49dp4dMhhFi4ygBiZGEnfz7Cqhngg*kPvQEkvbt23374ZHjnCjK2U5hBb4n8RHS*h-53gMXeUghS6XvUQW57zGcg19SM8Hkeb-97qH6wjvirAQf0SQn-MC4RORA*wllqDma*vgliXFNNHtR0hQl*4Dz4nM*K7hQOEOEmPq*uYsfeJaCmNGFHQbW0rbDueWMg2C0mFjWJJyMxlPbdYPQaZkPZ3mfuiN7NbUmw9C1h*PAdZxVOHWd8XQ*WgbjYBh6qAnVQ00*b7IiR5MnT0DUBkROpdShynZ*8AKkVGAIwKmhhFZKSDA6XGqhGpcXOhHOFDCFmsDvvlaPs94qB3EARl7RFgpMRe8eCajkORssoh-R2hhY1sDoG2v1CMIISkVBGsiYK*0xNb5haawkwQUYNzyRvfvu6ApBcyxemw5oB6kr1IFtpNCgjeB5cZGfEiV08*KrCYuaZ822UNtdQZeDwilWOGJVO*OKeL*NLiqSUQb4APtoB*JISZc-3Sc0bcPjn7u4K3Y9LNr5Akv4p0YYxJsGoeuH-oLPb7*5eOYirUqvc9LFU*-VuPq2aa-vow6G5W38JKOgzXCiLOUnk*vHbmnOS6ENb7bGLYUTiK7K8hSyDVaP-0VVVLu-y7BUHz*9o3Ez5Utte7EymgHuGiRGeErZoQ3b-wr7ziUKvV3HqL23-wDSniCdxwUAAA__' Name ='cv.actionState' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=cv.actionState",
		"LB=\"cv.actionState\": \"",
		"RB=\", ",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/cognos.cgi*",
		LAST);
		
	//web_reg_save_param("conversation", "LB=, \"m_sConversation\": \"", "RB=\"", LAST);
  web_reg_save_param("CAFContext", "LB=window.oCV_NS_.setCAFContext(", "RB=\");", LAST);
	//web_reg_save_param("sConversation", "LB=m_sConversation\": ", "RB=\", \"", LAST);
	
web_reg_save_param_ex(
	"ParamName=m_sConversation_1",
	"LB=\"m_sConversation\": \"",
		"RB=\", ",
	SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/cognos.cgi*",
		LAST);
//	web_reg_save_param_regexp(
//		"ParamName=CorrelationParameter",
//		"RegExp=\"m_sConversation\":\\ \"(\\w+-7s3sXw9y-.*?\\*.*?\\*.*?-.*?-\\w+\\*.*?\\*.*?-.*?\\*\\w+-.*?\\*.*?\\*.*?\\*.*?-.*?\\*.*?\\*.*?-.*?-.*?-.*?-.*?-.*?-.*?-.*?\\*.*?\\*.*?-.*?\\*.*?\\*.*?\\*.*?)\"",
//		SEARCH_FILTERS,
//		"Scope=Body",
//		"RequestUrl=*/cognos.cgi*",
//		LAST);
	web_reg_save_param("Tracking", "LB=m_sTracking\": \"", "RB=\", \"", LAST);
	web_reg_save_param("executionParameters", "LB=m_sParameters\": \"", "RB=\", \"", LAST);
//"m_sParameters": "CAFS60000001e4AhQAAACE5OBMBEHkPmnwn-7s3sXw9y-1cAcAAABTSEEtMjU2IAAAAPx61-Y8EAGWtgeod1CXYQ0VgORl26sUDzJdl5H8bK5hH4sIAAAAAAAAALVTXWvCMBR9dr9i5N3Gj7dSC2XKGGxOpoyByIjtRQNtEnLT1v77pa2t1alPW19Scs8595x7ibdN0VVMswQMaHw8JLFA115OyN4Y5VIaQQaxVKCdUO6ERHskFMM9JAzpllsoHVNyJB6Qt8Q8z5187Ei9o6PBYEi-3l6XFa3PBRomQrAs5K4pFEzI8j1Y9GfzJzfQmhWNXnPbih4bO7aMkqlKvfyhIEIZcbGzVlopVkqtKvmzmJ8sTmE92hD-oVd9HjeQdMz8RrfQnlcWhS118Ad00WjbnfiL1fc0WM0*gvnzzKMN9pydlYp3st8JkFRuXqzd9fDk-3oC5ImKYdEldRi1FS7COEWeXaTZShkDE8Q3OoU6Rou8lIg4qpgVN8ahIeMyxccpK2qdI-xSJcUbAy2ihmkhncC0THyaK20H2y71DPGHK1ZTUNL873IHG0KvBqnbnl6s-wPfF9EXwgMAAA__
	//"m_sConversation": "CAFS6000000b4cAhQAAACE5OBMBEHkPmnwn-7s3sXw9y-1cAcAAABTSEEtMjU2IAAAAFX7-6FCHQJq94EEzFpecjsA9lm8C3qL3pYUJNFuSlUVH4sIAAAAAAAAANVZWXPaShZ*zvwKrqfuzQMVa998k9QIJGF2zGJsp1KuVqsRAqkltLH8*mkhIODYDsaO7wwvUK3TR9-ZFz6bSXQRhI4HwmUXzRIUxYWF5*Logjz4cjaO4*CCoiyUItcPUHgOfRv7EfnyqAiOkQciynQIKcVRZ5uLi8jZXZzP5*dz7twPbYqlaYa6aTZ662ufHBzFAENEbkXORbwM0JezDAuIlhiON1DOvv7rQ-b5nD3BwEN7xIvoIopDB9tnX8MEf6a2JPtXfHOCYNwB8fjBWyIEQjjOHvQIBxe114RnXyno4xjhmBr5roXCb--JOH75qHsotBGGS6qLAuCEH79TIQr8MN4SlKrNarvAEBELnwrteIzCgpbEDooKVEGNCUerUAFRQY8gCFCh5pvRx*855B8QD4AHsePjaA91r612Pumt8oUahmC51fX2dKfwjVHOyePIB8Fa89kPiqD3LSIrMdOOFchY9XdKyV-6jZG-b-X*4bMTI**B7oi222vKku*7COAd8aNmOrih48Qj5kJxEuJ2EgdJPBwjrKbAcYHpop*MuGGZAjd5YHpz**44TDb31lQ74FSG-DkxckfLcVVx-Gsp9i-kgmziZgicuD8OUTQmTvMCGZzsrdxJ4IkzotCBORgSVHpmXWSRX8-LsRc0z4U2RCbIQiEL0TjaBkUTYGCjsAyIj-1Qw7-XTxfxsYJnZ8Q79xFvoOCV5a28JbuyTMebeOdAkgSJZySZ5RTpHHhg5WMwXyO8UDiapgI2sKgIhamLYspyogDEcHx--8eff-5xf58H6FWCwuX26D2je-tOk7MYiRdMCyi8xNIKFCwRcSORVniFgYwJRcWEkJGBTDMQWqaAJFMSTRaIgggkgLZ8AgCnRPvHyMPcd3JiAoPa3Ns*G-rh1A*tTAIQE5WG8Q*ogmiagmwpyCRoFJEVeQkKMieyAIisxUDAIYblWETTCMiyyJg8TYtAAcASgMLIcMsHQOgn*FD1Ci-KosTy9PZAFCUiokK4EJF5iSgXSSzLmkARZAQkThGVkSlwDG2xHLR4JEMGjGSag7wiEL2NtnxOCp9dQsqTEPFFEESJC7KjF6cz-2ceL4mFR67nfLGPT8tsO3y9dajnBeM0qQw-9MDRof2wRj1WaHYZ6Bvzo8z8LMdeorrsNxtGCGyPePqh8B9ep54WEeg6u3uahhaR2wEhIYtRGL2lirac1ti*Sc*p6YB0j*5Xyb98nXc8XTR6BPnTJWt7f*5gy5*f**XrR0zw0AhvB3uOzK7vP*aPv4ZMOaaXl7h3hVy*7pXfSte98rtCH0SorKl9tUfAZ93oSeif6M9*o8LXNr520ByFVe0kzPet3mN15fdhzp6Q7gWi6mP94-8gYOIaRuK6ndCLy74XOC46DfgIuNFR7vHqFl-fzD*n9PkgjknPm9WfLZeXFPjt5JXzalab*quFOXryekQWdw6WURVDN7FQ52Dwf9fxa1dMVbwcdKunVN9Bt-ECyLtlQXpO7r4O86mTbxCSYPn-0nPeBzZ8*KLG9rQ5k6AnYxdxyLxgbl*6njKzMQ*FBsk0vWVECF8-Nh*jkN8xL0eOjUGchC9Zd2xB0CxDhq7sI-M6r9N8meZ5Ruc5XVQMWjEMXS9relkwaENiDUOQaFrK6QWOl3mG1TiWE8hIlx-SGq3ytGHICltSJU5UVFriSobElGhOKJdKJU7QGU1R1JJmsCWDJbMZzQq8qCuspsmCIv8zYRQhN29JSiBCloHW2jy6BX-bsDpqdfQAP3Hk2IHA1V2UFZWXIF-vjFj6n9E7sNJsZWvlU-Mp*n6q3r8HeNf15yrGfgye6mbfA34DYDshaeE1U3mWGI-flv6eqRzhT7b5Fk3aQU4*yrinJWXT0ZwwTxvA3UvHB*fbXKLjbB-9kmXuy3xks-vPt-z7i-9gt1F4393-7r350oF9-i*AQ*qjrdXp35N5Uu*qrYr*1gsTAslbo6kSuM97cUYeOV7gos7*pZ-GHydrkiMn-XXx2FE*ZJEtpV2wfEIdIUodP4kKGljmfDbkD7kk0RMKXVrbm4TkbWenE00caCh4dEHzhsalv59Rz0TVjxDaD6woQNAZOXlH*b6xlQ9hvX0A*zLk8EhVQtlK-vl-Sv5y4793pH-Z8d*XfFRVNx*KG3ZvWKrfLPWNlA9HZVv206l0U*vCMX1T1PxbZrjqqp0Bfw2F1e2qV1zYnDBhWLFFa80rzZRAe3RDYew1VWhYsV1UxNRjyoMJHnKxIfMqHM0u*WEczsZIs716Q7ue3oymwA4GXNHpX0pOz6v1xS41kWZMXV2trO5gkFTCG8sxWiV1MklnI1SuX4X1Shf3U6*7MLmhwNAlejGGRdFXxrV*Dd6yV0i8iQZyl0nby*h6VvcTZjke9RVrSNdro5no1RfeGPbCwGwY3eCqp8tQqTJpJUnAdb2edLjZihnN521HXMirIcNTzixpak2kIScSWymYh5wkcAkRW089lkHdJYeLyxWVYt7HHMNblUvPr90CC1jaZHV3V0RjhW0OQ0ZKdXpCj4vKFNW7lWnzhmq3k-bVtNPGjaqlWLPKss83BHaBLp1lYooyp86udHlwFxUrlanmzQNnump6EF-zfrt9O2Zb0tSVZR-yLGh17Ut2jq9EfDmib*udWqNSK01EIW2xVmrNAOSLCmPYsXsn9kiJA8kKVXFYW1U1XfCDcTARg3J-aLW62pJTwKQ7XLh3thqpImuaFF2nqD43CJolq9r3*qk5uL0K5v5N-Y5TazAFbL3pL6oz1DehSJfVoGQbZbukEsP6xqLV5pvDgUpXtctZt5aUirzRdwZA6jkILObNCWXXGqP*FV7amSt**ZI5KXXgpXlg7o5yx99E68EK4ut-ATzop7*QIAAA", "m_sTracking": "CAFS600000017cAhQAAACE5OBMBEHkPmnwn-7s3sXw9y-1cAcAAABTSEEtMjU2IAAAAAyc9OdiyOymKfN7Im7oGDbsdk14Q9r8an6JaSvnU7xNH4sIAAAAAAAAAHWRsW6DMBCG5-YpKvbGlBAlIMJCpapSmbJ0JXABI7CJ72LD29eJq4hWxIsl3-f9Z5*T4wXjUgoNCgviUmRSEIz0MvadwNhW915DNMSMVaChkwOoVSlrIdFuPcOygb5AduQWZWvm-Yoj8rtojFmZ9UqqmgW*-8a*86-DTXvlAqkQJVgLeUzTAHvvwYW89PnpupJrvTiduOA0HUiBqKmZ6SPGXFh64-t*wpbgeRCv-qpIiovaSzOtoxaxNTrPdm2mo1w3H41pQ9yFeO6a6RxOU2ci14FX80whK-h8X84NNs5wzNwalCwB8b94e0sQbreBE*-Y3LVDpAsud7SfNHRA4HRHOtedLIw6-QFZHLifFQIAAA__", "m_aSecRequests": [ "forward", "back", "release" ], "m_sCAFContext": "CAFW000000a0Q0FGQTYwMDAwMDAwMDlBaFFBQUFDRTVPQk1CRUhrUG1ud24tN3Mzc1h3OXktMWNBY0FBQUJUU0VFdE1qVTJJQUFBQUczbG96WFJCOEFsTzg0UmthYlBpeipFYmJQU2xESnhFdFJIM2VjbjJlTUo0MjMyMjZ8cnY_", "outputFormat": "HTML", "m_sParameters": "CAFS60000001e4AhQAAACE5OBMBEHkPmnwn-7s3sXw9y-1cAcAAABTSEEtMjU2IAAAAPx61-Y8EAGWtgeod1CXYQ0VgORl26sUDzJdl5H8bK5hH4sIAAAAAAAAALVTXWvCMBR9dr9i5N3Gj7dSC2XKGGxOpoyByIjtRQNtEnLT1v77pa2t1alPW19Scs8595x7ibdN0VVMswQMaHw8JLFA115OyN4Y5VIaQQaxVKCdUO6ERHskFMM9JAzpllsoHVNyJB6Qt8Q8z5187Ei9o6PBYEi-3l6XFa3PBRomQrAs5K4pFEzI8j1Y9GfzJzfQmhWNXnPbih4bO7aMkqlKvfyhIEIZcbGzVlopVkqtKvmzmJ8sTmE92hD-oVd9HjeQdMz8RrfQnlcWhS118Ad00WjbnfiL1fc0WM0*gvnzzKMN9pydlYp3st8JkFRuXqzd9fDk-3oC5ImKYdEldRi1FS7COEWeXaTZShkDE8Q3OoU6Rou8lIg4qpgVN8ahIeMyxccpK2qdI-xSJcUbAy2ihmkhncC0THyaK20H2y71DPGHK1ZTUNL873IHG0KvBqnbnl6s-wPfF9EXwgMAAA__", "m_sActionState": "CAFS60000002e8AhQAAACE5OBMBEHkPmnwn-7s3sXw9y-1cAcAAABTSEEtMjU2IAAAAA*nUuRKP6uREvGCt3INh4-seiIlLQq-DaH-KdLq4JEmH4sIAAAAAAAAALVUTXObMBD9K5zq9mCEP4EpprWN6ZBpa49dp4dMhhFi4ygBiZGEnfz7Cqhngg*kPvQEkvbt23374ZHjnCjK2U5hBb4n8RHS*h-53gMXeUghS6XvUQW57zGcg19SM8Hkeb-97qH6wjvirAQf0SQn-MC4RORA*wllqDma*vgliXFNNHtR0hQl*4Dz4nM*K7hQOEOEmPq*uYsfeJaCmNGFHQbW0rbDueWMg2C0mFjWJJyMxlPbdYPQaZkPZ3mfuiN7NbUmw9C1h*PAdZxVOHWd8XQ*WgbjYBh6qAnVQ00*b7IiR5MnT0DUBkROpdShynZ*8AKkVGAIwKmhhFZKSDA6XGqhGpcXOhHOFDCFmsDvvlaPs94qB3EARl7RFgpMRe8eCajkORssoh-R2hhY1sDoG2v1CMIISkVBGsiYK*0xNb5haawkwQUYNzyRvfvu6ApBcyxemw5oB6kr1IFtpNCgjeB5cZGfEiV08*KrCYuaZ822UNtdQZeDwilWOGJVO*OKeL*NLiqSUQb4APtoB*JISZc-3Sc0bcPjn7u4K3Y9LNr5Akv4p0YYxJsGoeuH-oLPb7*5eOYirUqvc9LFU*-VuPq2aa-vow6G5W38JKOgzXCiLOUnk*vHbmnOS6ENb7bGLYUTiK7K8hSyDVaP-0VVVLu-y7BUHz*9o3Ez5Utte7EymgHuGiRGeErZoQ3b-wr7ziUKvV3HqL23-wDSniCdxwUAAA__", "envParams":
	//	web_reg_save_param("m_sParameters_1", "LB=\"m_sConversation\": \"", "RB=\", \"m_sTracking", LAST);

	//	web_reg_save_param("sConversation", "LB=m_sConversation\": ", "RB=\", \"m_sTracking", LAST);
	
		lr_start_transaction("Cognos_DevCloud_T04_ClkonReport");
	
	

	web_reg_find("Text=BIMIO 1001 - Other Duties / Attend Gas Escape Jobs - IBM Cognos Viewer", 
		LAST);

	web_link("BIMIO 1001 - Other Duties / Attend Gas Escape Jobs",
		"Text=BIMIO 1001 - Other Duties / Attend Gas Escape Jobs",
		"Snapshot=t5.inf",
		EXTRARES,
		"URL=../prompting/reportskin/prompting/promptCommon.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../schemas/GlobalReportStyles_10.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../prompting/res/promptingStrings_en.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../prompting/properties.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../prompting/res/promptLocale_en.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../prompting/res/promptLocale_en-gb.js", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/viewer/QSRVCommon.css", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/prompting/images/icon_tree_I.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/prompting/images/icon_tree_L.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/prompting/images/blank.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../prompting/reportskin/prompting/images/icon_datepicker.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../reportstyles/images/silver_grad.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../prompting/reportskin/prompting/images/icon_year_up.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../prompting/reportskin/prompting/images/blank.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../prompting/reportskin/prompting/images/icon_year_down.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../prompting/reportskin/prompting/images/spacer.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../reportstyles/images/prompt_footer_bg.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../reportstyles/images/button_bg.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../reportstyles/images/button_disabled_bg.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../rv/images/action_run.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/portal/images/dropdown_arrow_narrow.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../rv/images/action_keep_report.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../rv/images/action_go_to.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../rv/images/dis_action_drill_down.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../rv/images/dis_action_drill_up.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../rv/images/action_view_html.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../rv/images/action_add_report.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../common/images/spacer.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/shared/images/action_return.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../reportstyles/images/calendar_selection.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../reportstyles/images/button_hover_bg.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/branding/progress.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		LAST);

	lr_end_transaction("Cognos_DevCloud_T04_ClkonReport",LR_AUTO);
	
	lr_think_time(5);
	
	web_reg_save_param("var_actionState", "LB=m_sActionState&quot;: &quot;", "RB=&quot;", LAST);
	
		
			web_reg_save_param("var_m_tracking", "LB=m_sTracking&quot;: &quot;", "RB=&quot;", LAST);   
    web_reg_save_param("status", "LB=m_sStatus&quot;: &quot;", "RB=&quot;","Ord=All",  LAST);   
    web_reg_find("Text=working", "SaveCount=currstatus", "Search=All", LAST);

	lr_start_transaction("Cognos_DevCloud_T05_SelectReportFinish");

	web_custom_request("cognos.cgi_4",
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F",
		"Snapshot=t6.inf",
		"Mode=HTML",
		"Body=_promptControl=prompt&b_action=cognosViewer&cv.actionState={cv.actionState}&cv.catchLogOnFault=true&cv.id=_NS_&cv.objectPermissions=execute%20read%20traverse%20&cv.responseFormat=data&cv.showFaultPage=true&errURL=%2Fibmcognos%2Fcgi-bin%2Fcognos.cgi%3Fb_action%3Dxts.run%26m%3Dportal%2Fcc.xts%26m_folder%3DiB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3Dm-i937E6052F9724D988EF69846A3CD4D2F&executionParameters={executionParameters}&m_tracking={Tracking}&p_PT_DATEFROM=%3CselectChoices%3E%3CselectOption%20useValue%3D%222018-04-06%22%20displayValue%3D%226%20Apr%202018%22%2F%3E%3C%2FselectChoices%3E&p_PT_DATERANGE=%3CselectChoices%3E%3CselectOption%20useValue%3D%22wk%22%20displayValue%3D%22Last%207%20Days%22%2F%3E%3C%2FselectChoices%3E&p_PT_DATETO=%3CselectChoices%3E%3CselectOption%20useValue%3D%222018-04-13%22%20displayValue%3D%2213%20Apr%202018%22%2F%3E%3C%2FselectChoices%3E&p_pDepot=%3CselectChoices%3E%3C%2FselectChoices%3E&run.prompt=false&ui.action=forward&ui.backURL=%2Fibmcognos%2Fcgi-bin%2Fcognos.cgi%3Fb_"
		"action%3Dxts.run%26m%3Dportal%2Fcc.xts%26m_folder%3DiB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3Dm-i937E6052F9724D988EF69846A3CD4D2F&ui.cafcontextid={CAFContext}&ui.conversation={m_sConversation_1}&ui.object=%2Fcontent%2Ffolder%5B%40name%3D'Emergency%2FRepair'%5D%2Freport%5B%40name%3D'BIMIO%201001%20-%20Other%20Duties%20%2F%20Attend%20Gas%20Escape%20Jobs'%5D&ui.objectClass=report&ui.primaryAction=run",
		EXTRARES,
		"URL=../rv/images/action_save_report_view.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../rv/images/action_send_report.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		LAST);
	
	if ((atoi(lr_eval_string("{currstatus}"))>0))
	{
		do
{
			i++;
   // web_reg_save_param("var_actionState", "LB=m_sActionState&quot;: &quot;", "RB=&quot;", LAST);
	web_reg_save_param("var_m_tracking", "LB=m_sTracking&quot;: &quot;", "RB=&quot;", LAST);   
    web_reg_save_param("status", "LB=m_sStatus&quot;: &quot;", "RB=&quot;","Ord=All",  LAST);   
    web_reg_find("Text=stillWorking", "SaveCount=currstatus", "Search=All", LAST);

	web_submit_data("cognos.cgi_5",
		"Action=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi",
		"Method=POST",
		"RecContentType=text/plain",
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F",
		"Snapshot=t7.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=b_action", "Value=cognosViewer", ENDITEM,
		"Name=cv.actionState", "Value={cv.actionState}", ENDITEM,
		"Name=cv.catchLogOnFault", "Value=true", ENDITEM,
		"Name=cv.responseFormat", "Value=data", ENDITEM,
		"Name=cv.showFaultPage", "Value=true", ENDITEM,
		"Name=errURL", "Value=/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/cc.xts&m_folder=iB7FD0C77FA084DD3B5005F5346799DF8&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"Name=m_tracking", "Value={var_m_tracking}", ENDITEM,
		"Name=ui.action", "Value=wait", ENDITEM,
		"Name=ui.backURL", "Value=/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/cc.xts&m_folder=iB7FD0C77FA084DD3B5005F5346799DF8&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"Name=ui.primaryAction", "Value=run", ENDITEM,
		LAST);
	

	  
     }	while(atoi(lr_eval_string("{currstatus}"))==1);

	}
	
	

	/*web_submit_data("cognos.cgi_6",
		"Action=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi",
		"Method=POST",
		"RecContentType=text/plain",
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F",
		"Snapshot=t8.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=b_action", "Value=cognosViewer", ENDITEM,
		"Name=cv.actionState", "Value={cv.actionState}", ENDITEM,
		"Name=cv.catchLogOnFault", "Value=true", ENDITEM,
		"Name=cv.responseFormat", "Value=data", ENDITEM,
		"Name=cv.showFaultPage", "Value=true", ENDITEM,
		"Name=errURL", "Value=/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/cc.xts&m_folder=iB7FD0C77FA084DD3B5005F5346799DF8&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"Name=m_tracking", "Value=CAFS6000000180AhQAAACE5OBMBEHkPmnwn-7s3sXw9y-1cAcAAABTSEEtMjU2IAAAABTVhyNDFJgnBjPYKGDdwzN2o6eyrRjPjzb9SoEnoaM6H4sIAAAAAAAAAHWQsW6DMBCG5-YpKvZiSogSEGGhUlWpTBnalYCDTcEmvosNb18nriIaUS*Wfd-3n33p4QxJJYWmCkrkUuRSIB3xaew7AYmt7jyGOCSE1FTTTg5U*ZVshAS79QQqRvsSyIFblKyI9yuOwG*iMcY3K1*qhoRB8EK*io-9VXvmArAUFbUW8ASnge68fx7kZY8Pl5Ve6uXxyAXHaY*KigbZTB8h4cLS6yAIUrIEz4N4-VcFVFw0XpZrHbcArdFFvm1zHReavTHTRrCN4NSx6RRNU2di14HX80wha-r*upwbrp3hmLk1KFlRgHvx*pcw2mxCJ96wuWuHiGdY7gjIu*5Tqm97chGOdr67WRh39gNnmV-HGQIAAA__", ENDITEM,
		"Name=ui.action", "Value=wait", ENDITEM,
		"Name=ui.backURL", "Value=/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/cc.xts&m_folder=iB7FD0C77FA084DD3B5005F5346799DF8&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"Name=ui.primaryAction", "Value=run", ENDITEM,
		LAST);

	web_submit_data("cognos.cgi_7",
		"Action=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi",
		"Method=POST",
		"RecContentType=text/plain",
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F",
		"Snapshot=t9.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=b_action", "Value=cognosViewer", ENDITEM,
		"Name=cv.actionState", "Value={cv.actionState}", ENDITEM,
		"Name=cv.catchLogOnFault", "Value=true", ENDITEM,
		"Name=cv.responseFormat", "Value=data", ENDITEM,
		"Name=cv.showFaultPage", "Value=true", ENDITEM,
		"Name=errURL", "Value=/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/cc.xts&m_folder=iB7FD0C77FA084DD3B5005F5346799DF8&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"Name=m_tracking", "Value=CAFS6000000180AhQAAACE5OBMBEHkPmnwn-7s3sXw9y-1cAcAAABTSEEtMjU2IAAAABTVhyNDFJgnBjPYKGDdwzN2o6eyrRjPjzb9SoEnoaM6H4sIAAAAAAAAAHWQsW6DMBCG5-YpKvZiSogSEGGhUlWpTBnalYCDTcEmvosNb18nriIaUS*Wfd-3n33p4QxJJYWmCkrkUuRSIB3xaew7AYmt7jyGOCSE1FTTTg5U*ZVshAS79QQqRvsSyIFblKyI9yuOwG*iMcY3K1*qhoRB8EK*io-9VXvmArAUFbUW8ASnge68fx7kZY8Pl5Ve6uXxyAXHaY*KigbZTB8h4cLS6yAIUrIEz4N4-VcFVFw0XpZrHbcArdFFvm1zHReavTHTRrCN4NSx6RRNU2di14HX80wha-r*upwbrp3hmLk1KFlRgHvx*pcw2mxCJ96wuWuHiGdY7gjIu*5Tqm97chGOdr67WRh39gNnmV-HGQIAAA__", ENDITEM,
		"Name=ui.action", "Value=wait", ENDITEM,
		"Name=ui.backURL", "Value=/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/cc.xts&m_folder=iB7FD0C77FA084DD3B5005F5346799DF8&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"Name=ui.primaryAction", "Value=run", ENDITEM,
		EXTRARES,
		"URL=../skins/corporate/viewer/images/top_dis.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/viewer/images/pageup_dis.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=http://10.70.39.5/ibmcognos/images/SGN_logo_Cognos.png", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/viewer/images/pagedown.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/viewer/images/bottom.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		"URL=../skins/corporate/viewer/images/tool_sep_dot_line.gif", "Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM,
		LAST);*/

	lr_end_transaction("Cognos_DevCloud_T05_SelectReportFinish",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("Cognos_DevCloud_T06_Logout");

	web_custom_request("cognos.cgi_8",
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/xml",
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F",
		"Snapshot=t10.inf",
		"Mode=HTML",
		"Body=b_action=cognosViewer&cv.catchLogOnFault=true&cv.objectPermissions=execute%20read%20traverse%20&cv.responseFormat=successfulRequest&m_tracking=CAFS600000017cAhQAAACE5OBMBEHkPmnwn-7s3sXw9y-1cAcAAABTSEEtMjU2IAAAAAyc9OdiyOymKfN7Im7oGDbsdk14Q9r8an6JaSvnU7xNH4sIAAAAAAAAAHWRsW6DMBCG5-YpKvbGlBAlIMJCpapSmbJ0JXABI7CJ72LD29eJq4hWxIsl3-f9Z5*T4wXjUgoNCgviUmRSEIz0MvadwNhW915DNMSMVaChkwOoVSlrIdFuPcOygb5AduQWZWvm-Yoj8rtojFmZ9UqqmgW*-8a*86-DTXvlAqkQJVgLeUzTAHvvwYW89PnpupJrvTiduOA0HUiBqKmZ6SPGXFh64-t*wpbgeRCv-qpIiovaSzOtoxaxNTrPdm2mo1w3H41pQ9yFeO6a6RxOU2ci14FX80whK-h8X84NNs5wzNwalCwB8b94e0sQbreBE*-Y3LVDpAsud7SfNHRA4HRHOtedLIw6-QFZHLifFQIAAA__&ui.action=release&ui.objectClass=report&ui.primaryAction=run",
		LAST);

	web_reg_find("Text=Log off", 
		LAST);

	web_url("cognos.cgi_9",
		"URL=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=xts.run&m=portal/logoff.xts&h_CAM_action=logoff",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://10.184.11.70/ibmcognos/cgi-bin/cognos.cgi?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27Emergency%2fRepair%27%5d%2freport%5b%40name%3d%27BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs%27%5d&ui.name=BIMIO%201001%20-%20Other%20Duties%20%2f%20Attend%20Gas%20Escape%20Jobs&run.outputFormat=&run.prompt=true&ui.backURL=%2fibmcognos%2fcgi-bin%2fcognos.cgi%3fb_action%3dxts.run%26m%3dportal%2fcc.xts%26m_folder%3diB7FD0C77FA084DD3B5005F5346799DF8%26m_folder2%3dm-i937E6052F9724D988EF69846A3CD4D2F",
		"Snapshot=t11.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("Cognos_DevCloud_T06_Logout",LR_AUTO);
	
	lr_think_time(5);

	return 0;
}