Action()
{
	int i;
	
	web_cache_cleanup();
	web_set_max_html_param_len("1024");
	web_reg_find("Text=Welcome to Maximo Project UAT", 
		LAST);

/*Correlation comment - Do not change!  Original value='1524403721660' Name ='loginstamp' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=loginstamp",
		"TagName=input",
		"Extract=value",
		"Name=loginstamp",
		"Id=loginstamp",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/login.jsp*",
		LAST);
		
		lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T01_Launch");


	web_url("login.jsp", 
		"URL=http://porud755/maximo/webclient/login/login.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/ge_login_dialog_bkgnd.png", ENDITEM, 
		"Url=images/ge_login_bkgnd.jpg", ENDITEM, 
		"Url=images/ge_bkgnd.png", ENDITEM, 
		"Url=images/buttonEnabled_tiv.png", ENDITEM, 
		"Url=images/ge_login_txtbox.png", ENDITEM, 
		LAST);
		
		lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T01_Launch", LR_AUTO);

		lr_think_time(5);
	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T02_Login");

	web_reg_find("Text=Start Center", 
		LAST);

///*Correlation comment - Do not change!  Original value='gc4p438j5hqvsqqv4bqepi5rad' Name ='csrftoken' Type ='ResponseBased'*/
//	web_reg_save_param_ex(
//		"ParamName=csrftoken",
//		"LB=csrftoken=",
//		"RB=\";\n\t\t\tvar XHRACTION ",
//		SEARCH_FILTERS,
//		"Scope=Body",
//		"IgnoreRedirections=No",
//		"RequestUrl=*/login*",
//		LAST);



	web_reg_save_param("csrftoken","LB=csrftoken=","RB=\";",LAST);
	
	
	web_reg_save_param("uisessionid","LB=maximo.jsp?uisessionid=","RB=&",LAST);
	
	
	web_reg_save_param("currentfocus","LB= id=\"","RB=_holder","Ordinal=2",LAST);
				
///*Correlation comment - Do not change!  Original value='mx45' Name ='currentfocus' Type ='ResponseBased'*/
//	web_reg_save_param_ex(
//		"ParamName=currentfocus",
//		"LB= id=\"",
//		"RB=_holder",
//		"Ordinal=2",
//		SEARCH_FILTERS,
//		"Scope=Body",
//		"IgnoreRedirections=No",
//		"RequestUrl=*/login*",
//		LAST);

/*Correlation comment - Do not change!  Original value='mx57' Name ='currentfocus_1' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=currentfocus_1",
		"LB= id=\"",
		"RB=_holder",
		"Ordinal=6",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/login*",
		LAST);

	web_submit_data("login",
		"Action=http://porud755/maximo/ui/login",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/webclient/login/login.jsp",
		"Snapshot=t7.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=allowinsubframe", "Value=null", ENDITEM,
		"Name=mobile", "Value=false", ENDITEM,
		"Name=login", "Value=jsp", ENDITEM,
		"Name=loginstamp", "Value={loginstamp}", ENDITEM,
		"Name=username", "Value=SP51532", ENDITEM,
		"Name=password", "Value=Deepya!1", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/css/extended.css", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/row.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/sub_row.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/over.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/off.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/designer/formtabon_selected.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tb_button_highlight.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/working.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/edited.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/menusub.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/error.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/warning.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/question.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/smartfill.png", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/layers/mbs/popuplayer.js", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/ibm_logo_white.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/dialogs/drag_header_middle.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/wait.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg.png", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/number.js", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/fx.js", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/fx/Toggler.js", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/resources/blank.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_setup.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/blank.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_change.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_financial.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_asset.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_contract.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_configItems.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_int.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_inventor.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_plans.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_pm.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_purchase.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_sd.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_release.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_security.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_ssdr.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_sla.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_util.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_taskMgmt.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_wo.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/item_over.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/menuback.png", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T02_Login",LR_AUTO);
	
	lr_think_time(5);

	

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T04_GotoWO_ordertye");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("_QM_Try", 
		"1");

	web_add_header("pageseqnum", 
		"1");

	web_add_header("xhrseqnum", 
		"1");


	web_submit_data("maximo.jsp",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/login",
		"Snapshot=t8.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"changeapp\",\"targetId\":\"{currentfocus}\",\"value\":\"EMGWOTRACK\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_reg_find("Text=Emergency Work Order Tracking", 
		LAST);
	
	//mx527
	web_reg_save_param("currentfocus_1","LB= id=\"","RB=_holder","Ordinal=72",LAST);

	
	// id="mx314_anchor"
	
	web_reg_save_param("targetid_1","LB= id=\"","RB=_anchor","Ordinal=1",LAST);
	
	//tabindex="-1" id="mx297_anchor
	
	
	//role="presentation" id="mx297" ctype
	web_reg_save_param("tabindex","LB=tabindex=\"-1\" id=\"","RB=_anchor","Ordinal=16",LAST);
	
	//tabindex="-1" id="mx328_image"
	
	web_reg_save_param("tabindex2","LB=tabindex=\"-1\" id=\"","RB=_image","Ordinal=6",LAST);
	
	//tabindex="-1" id="mx282_anchor
	
	web_reg_save_param("tabindex3","LB=tabindex=\"-1\" id=\"","RB=_","Ordinal=12",LAST);
		
	web_url("ui",
		"URL=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/login",
		"Snapshot=t9.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbarsep.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_rcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_lcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_columnHeader_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_filterRow_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T04_GotoWO_ordertye",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T05_ClkonNewWordorder");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	
	
	//"XJOBTYPE" id="mx1026" tabindex=
	web_reg_save_param("JOBTYPE","LB=\"XJOBTYPE\" id=\"","RB=\" tabindex=",LAST);
	
	//XJOBPRIORITY" id="mx1275" tabindex=
	
	web_reg_save_param("JOBPRIORITY","LB=\"XJOBPRIORITY\" id=\"","RB=\" tabindex=","ORD=1",LAST);
	
	//mx1025
	web_reg_save_param("polite_1","LB=\"polite\" id=\"","RB=_holder\"","ORD=50",LAST);
	
	//mx1274
	web_reg_save_param("polite_2","LB=\"polite\" id=\"","RB=_holder\"","ORD=134",LAST);
	
	//mx1162
	web_reg_save_param("polite_4","LB=\"polite\" id=\"","RB=_holder\"","ORD=94",LAST);
	
	//mx1170
	
	web_reg_save_param("polite_5","LB=\"polite\" id=\"","RB=_holder\"","ORD=98",LAST);
	
	//title="Work Order: W114593667" value="
	
	web_reg_save_param("WorkOrder","LB=title=\"Work Order: ","RB=\" value=\"",LAST);

	web_submit_data("maximo.jsp_2",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t10.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_1}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{targetid_1}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/required.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/required_label.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_longdescription_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/cb_checked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_date_time.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_attachments.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/cb_uncheckedreadonly.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/cb_unchecked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/layers/mbs/calendar.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/islamic.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_lookup_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_menu_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T05_ClkonNewWordorder",LR_AUTO);
	
	lr_think_time(5);
	
	
	//"polite" id="mx1793[R:0]_holder"
	
	web_reg_save_param("polite","LB=\"polite\" id=\"","RB=[R:0]_holder\"",LAST);
	
	


	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T06_Jobtype");

	web_add_header("xhrseqnum", 
		"2");
 web_reg_find("Text=Gas Escape", LAST);
	
	web_submit_data("maximo.jsp_3",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t11.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={polite_1}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{JOBTYPE}\",\"value\":\"XJOBTYPE\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_nextdown_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_next_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_download.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"3");

	web_submit_data("maximo.jsp_4",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t12.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={polite}[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{polite}[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_longdescription_off_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T06_Jobtype",LR_AUTO);
	
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T07_JobPriority");

	web_add_header("xhrseqnum", 
		"4");


	
	//mx2015[R:0]
	
	web_reg_save_param("polite_7","LB=\"polite\" id=\"","RB=[R:0]_holder\"","ORD=1",LAST);

	
	web_submit_data("maximo.jsp_5",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t13.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={polite_2}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{JOBPRIORITY}\",\"value\":\"XJOBPRIORITY\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T07_JobPriority",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T08_Job_selectValue");

	web_add_header("xhrseqnum", 
		"5");

	

	web_submit_data("maximo.jsp_6",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t14.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={polite_7}[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{polite_7}[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_date_time_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en-gb/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T08_Job_selectValue",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T09_Schedule");

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("blank.html",
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/resources/blank.html",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t15.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/titleBar.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarYearLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteArrows.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteRoundedIconsSmall.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarDayLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/buttonEnabled.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"6");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	

	web_custom_request("maximo.jsp_7",
		"URL=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t16.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded;charset=UTF-8",
		"Body=uisessionid={uisessionid}&csrftoken={csrftoken}&currentfocus={polite_4}&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22{polite_4}%22%2C%22value%22%3A%2223%2F04%2F2018%2019%3A00%3A00%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%2223%2F04%2F2018%2019%3A00%3A00%22%2C%22csrftokenholder%22%3A%22{csrftoken}%22%7D%5D",
		LAST);

	web_add_header("xhrseqnum", 
		"7");

	

	web_custom_request("maximo.jsp_8",
		"URL=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t17.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded;charset=UTF-8",
		"Body=uisessionid={uisessionid}&csrftoken={csrftoken}&currentfocus={polite_5}&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22{polite_5}%22%2C%22value%22%3A%2226%2F04%2F2018%2019%3A30%3A00%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%2226%2F04%2F2018%2019%3A30%3A00%22%2C%22csrftokenholder%22%3A%22{csrftoken}%22%7D%5D",
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T09_Schedule",LR_AUTO);
	
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T10_ClkonAddress");

	web_add_header("xhrseqnum", 
		"8");
	web_reg_find("Text=WAPPR", LAST);

	//mx2187
	web_reg_save_param("polite_8","LB=\"polite\" id=\"","RB=_holder\"","ORD=36",LAST);
	
	//for="mx2245" title="MPRN">
	
	web_reg_save_param("MPRN","LB=for=\"","RB=\" title=\"MPRN\"",LAST);
	
	//mx2246
	
	web_reg_save_param("polite_9","LB=\"polite\" id=\"","RB=_holder\"","ORD=65",LAST);

	

	web_submit_data("maximo.jsp_9",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t18.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={polite_5}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{tabindex}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_filter_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/qf_find_disabled.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T10_ClkonAddress",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T11_NewRow");

	web_reg_find("Text=MPRN",LAST);

	web_add_header("xhrseqnum", 
		"9");

	

	web_submit_data("maximo.jsp_10",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t19.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={polite_8}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{polite_8}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_row_select.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T11_NewRow",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T12_ClkonMPRN");

	web_add_header("xhrseqnum", 
		"10");

	

	web_submit_data("maximo.jsp_11",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t20.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={MPRN}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{polite_9}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menu_icon_link.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T12_ClkonMPRN",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T3_GoToMeterPoint");

	web_add_header("xhrseqnum", 
		"11");

	

	web_submit_data("maximo.jsp_12",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t21.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={MPRN}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_mainrec_menus\",\"value\":\"normal1\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Meter Point", 
		LAST);
	
	
	//"polite" id="mx345_holder"
	
	web_reg_save_param("polite_10","LB=\"polite\" id=\"","RB=_holder\"","ORD=41",LAST);

	web_url("maximo.jsp_13",
		"URL=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t22.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T3_GoToMeterPoint",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T14_ClkonMPRN");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"3");
	
	//"polite" id="mx576[R:0]_holder"
	
	//targetid="mx576[R:0]"
	
	web_reg_save_param("polite_11","LB=\"polite\" id=\"","RB=[R:0]_holder","ORD=1",LAST);
	
	
	web_reg_find("Text=Select Records",LAST);

	

	web_submit_data("maximo.jsp_14",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t23.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{polite_10}\",\"value\":\"0\",\"requestType\":\"SYNC\",\"multi\":\"true\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/btn_addtobookmarks.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T14_ClkonMPRN",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T16_SelectAddress");

	web_add_header("xhrseqnum", 
		"2");

	
	web_reg_find("Text=39,018,439",LAST);
	
	//"Premise Id: 39,018,439" value="
	
	web_reg_save_param("Adress","LB=\"Premise Id: ","RB=\" value=\"",LAST);

	web_submit_data("maximo.jsp_15",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t24.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={polite_11}[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{polite_11}[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T16_SelectAddress",LR_AUTO);

	

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T17_ReturntoValue");

	web_add_header("xhrseqnum", 
		"3");

	

	web_submit_data("maximo.jsp_16",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t25.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={tabindex3}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{tabindex3}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Emergency Work Order Tracking", 
		LAST);

/*Correlation comment - Do not change!  Original value='mx2187' Name ='currentfocus' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=currentfocus",
		"LB= id=\"",
		"RB=_holder",
		"Ordinal=61",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("maximo.jsp_17",
		"URL=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t26.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T17_ReturntoValue",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T18_ClkonChangeStatus");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"4");

	
	//mx2960
	
	//db="mx2960"   maxlength

	web_reg_save_param("db1","LB=db=\"","RB=\"   maxlength","ORD=1",LAST);
	
	
	//for="mx2905" title="New Status"
	
	web_reg_save_param("Newstatus","LB=for=\"","RB=\" title=\"New Status\"",LAST);
	
	
	//"polite" id="mx2906_holder"
	
	//"textbox"   li="mx2906"
		
		
		web_reg_save_param("textbox4","LB=\"textbox\"   li=\"","RB=\"","ORD=5",LAST);
	web_submit_data("maximo.jsp_18",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t27.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={MPRN}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{tabindex2}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown_over.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T18_ClkonChangeStatus",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T19_SelectNewStatus");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_19",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t28.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={Newstatus}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{textbox4}\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"3");

	web_submit_data("maximo.jsp_20",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t29.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={Newstatus}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_FSCH_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T19_SelectNewStatus",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T20_ClkonOk");

	web_add_header("xhrseqnum", 
		"4");

	
	
	//title="Please wait..."
	 
	web_reg_save_param("Status","LB=title=\"","RB=\"","ORD=All",LAST);
	
	web_reg_find("Text=Please wait","SaveCount=currstatus", "Search=All",LAST);

	web_submit_data("maximo.jsp_21",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t30.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={db1}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{db1}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/progressbar.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	
	
	
	
	//if(strcmp(lr_eval_string("{Status}"),"Status: FSCH")==0)

		if ((atoi(lr_eval_string("{currstatus}"))>0))
		
		
	{
		do
{
			i++;
			
	
			
			web_reg_find("Text=Status change(s) completed successfully","SaveCount=currstatus", "Search=All",LAST);
    web_add_header("xhrseqnum", 
		"5");
    
	web_submit_data("maximo.jsp_22",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t31.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={db1}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);
    
    }	while(atoi(lr_eval_string("{currstatus}"))==1);

	}
		

	/*web_add_header("xhrseqnum", 
		"6");

	web_submit_data("maximo.jsp_23",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t32.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={db1}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"7");
	
	

	web_submit_data("maximo.jsp_24",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t33.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={db1}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"8");

	web_submit_data("maximo.jsp_25",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t34.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={db1}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"9");

	web_submit_data("maximo.jsp_26",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t35.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={db1}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	
	//web_reg_find("Text=Status change(s) completed successfully",LAST);
	
	// title="Status: FSCH" value=
	
	
	web_add_header("xhrseqnum", 
		"10");

	web_submit_data("maximo.jsp_27",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t36.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={db1}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);*/

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T20_ClkonOk",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Maximo_EmrgncyWR_ProjectUAT_T21_Logout");

	web_add_header("xhrseqnum", 
		"11");

	

	web_submit_data("maximo.jsp_28",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t37.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_1}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{currentfocus_1}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Welcome to Maximo Project UAT", 
		LAST);

	web_url("logout.jsp",
		"URL=http://porud755/maximo/webclient/login/logout.jsp?uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t38.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("Maximo_EmrgncyWR_ProjectUAT_T21_Logout",LR_AUTO);
	
	lr_think_time(5);

	return 0;
}