Action()
{

	web_reg_find("Text=Welcome to Maximo Project UAT", 
		LAST);

	web_url("login.jsp", 
		"URL=http://porud755/maximo/webclient/login/login.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/ge_login_dialog_bkgnd.png", ENDITEM, 
		"Url=images/ge_login_bkgnd.jpg", ENDITEM, 
		"Url=images/ge_bkgnd.png", ENDITEM, 
		"Url=images/buttonEnabled_tiv.png", ENDITEM, 
		"Url=images/ge_login_txtbox.png", ENDITEM, 
		LAST);

	lr_start_transaction("Login");

	web_reg_find("Text=Start Center", 
		LAST);

	web_submit_data("login", 
		"Action=http://porud755/maximo/ui/login", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=allowinsubframe", "Value=null", ENDITEM, 
		"Name=mobile", "Value=false", ENDITEM, 
		"Name=login", "Value=jsp", ENDITEM, 
		"Name=loginstamp", "Value=1524403721660", ENDITEM, 
		"Name=username", "Value=SP51532", ENDITEM, 
		"Name=password", "Value=Deepya!1", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/css/extended.css", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/row.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/sub_row.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/over.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/off.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/designer/formtabon_selected.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tb_button_highlight.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/working.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/edited.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/menusub.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/error.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/warning.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/question.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/smartfill.png", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/layers/mbs/popuplayer.js", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/ibm_logo_white.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/dialogs/drag_header_middle.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/wait.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg.png", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/number.js", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/fx.js", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/fx/Toggler.js", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/resources/blank.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_setup.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/blank.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_change.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_financial.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_asset.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_contract.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_configItems.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_int.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_inventor.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_plans.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_pm.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_purchase.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_sd.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_release.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_security.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_ssdr.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_sla.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_util.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_taskMgmt.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_wo.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/item_over.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/menuback.png", ENDITEM, 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_start_transaction("GoTO");

	lr_end_transaction("GoTO",LR_AUTO);

	lr_start_transaction("WorkOrder");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("_QM_Try", 
		"1");

	web_add_header("pageseqnum", 
		"1");

	web_add_header("xhrseqnum", 
		"1");

	lr_think_time(17);

	web_submit_data("maximo.jsp", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx45", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"changeapp\",\"targetId\":\"mx45\",\"value\":\"EMGWOTRACK\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		LAST);

	web_reg_find("Text=Emergency Work Order Tracking", 
		LAST);

	web_url("ui", 
		"URL=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbarsep.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_rcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_lcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_columnHeader_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_filterRow_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	lr_end_transaction("WorkOrder",LR_AUTO);

	lr_start_transaction("ClkonNewWordorder");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	lr_think_time(23);

	web_submit_data("maximo.jsp_2", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx527", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx314\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/required.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/required_label.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_longdescription_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/cb_checked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_date_time.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_attachments.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/cb_uncheckedreadonly.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/cb_unchecked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/layers/mbs/calendar.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/islamic.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_lookup_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_menu_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonNewWordorder",LR_AUTO);

	lr_start_transaction("Jobtype");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_3", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx1025", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1026\",\"value\":\"XJOBTYPE\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_nextdown_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_next_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_download.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"3");

	web_submit_data("maximo.jsp_4", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx1793[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1793[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_longdescription_off_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	lr_end_transaction("Jobtype",LR_AUTO);

	lr_start_transaction("JobPriority");

	web_add_header("xhrseqnum", 
		"4");

	lr_think_time(16);

	web_submit_data("maximo.jsp_5", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx1274", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1275\",\"value\":\"XJOBPRIORITY\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("JobPriority",LR_AUTO);

	lr_start_transaction("Job_selectValue");

	web_add_header("xhrseqnum", 
		"5");

	lr_think_time(48);

	web_submit_data("maximo.jsp_6", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2015[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2015[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_date_time_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en-gb/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	lr_end_transaction("Job_selectValue",LR_AUTO);

	lr_start_transaction("Schedule");

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("blank.html", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/resources/blank.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/titleBar.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarYearLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteArrows.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteRoundedIconsSmall.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarDayLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/buttonEnabled.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"6");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	lr_think_time(6);

	web_custom_request("maximo.jsp_7", 
		"URL=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad&currentfocus=mx1162&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22mx1162%22%2C%22value%22%3A%2223%2F04%2F2018%2019%3A00%3A00%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%2223%2F04%2F2018%2019%3A00%3A00%22%2C%22csrftokenholder%22%3A%22gc4p438j5hqvsqqv4bqepi5rad%22%7D%5D", 
		LAST);

	web_add_header("xhrseqnum", 
		"7");

	lr_think_time(7);

	web_custom_request("maximo.jsp_8", 
		"URL=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad&currentfocus=mx1170&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22mx1170%22%2C%22value%22%3A%2226%2F04%2F2018%2019%3A30%3A00%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%2226%2F04%2F2018%2019%3A30%3A00%22%2C%22csrftokenholder%22%3A%22gc4p438j5hqvsqqv4bqepi5rad%22%7D%5D", 
		LAST);

	lr_end_transaction("Schedule",LR_AUTO);

	lr_start_transaction("ClkonAddress");

	web_add_header("xhrseqnum", 
		"8");

	lr_think_time(14);

	web_submit_data("maximo.jsp_9", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx1170", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx297\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_filter_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/qf_find_disabled.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonAddress",LR_AUTO);

	lr_start_transaction("NewRow");

	web_reg_find("Text=Gas Escape", 
		LAST);

	web_add_header("xhrseqnum", 
		"9");

	lr_think_time(12);

	web_submit_data("maximo.jsp_10", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2187", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2187\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_row_select.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	lr_end_transaction("NewRow",LR_AUTO);

	lr_start_transaction("ClkonMPRN");

	web_add_header("xhrseqnum", 
		"10");

	lr_think_time(53);

	web_submit_data("maximo.jsp_11", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2245", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2246\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menu_icon_link.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonMPRN",LR_AUTO);

	lr_start_transaction("GoToMeterPoint");

	web_add_header("xhrseqnum", 
		"11");

	lr_think_time(19);

	web_submit_data("maximo.jsp_12", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2245", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_mainrec_menus\",\"value\":\"normal1\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Meter Point", 
		LAST);

	web_url("maximo.jsp_13", 
		"URL=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	lr_end_transaction("GoToMeterPoint",LR_AUTO);

	lr_start_transaction("ClkonMPRN");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"3");

	lr_think_time(28);

	web_submit_data("maximo.jsp_14", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx345\",\"value\":\"0\",\"requestType\":\"SYNC\",\"multi\":\"true\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/btn_addtobookmarks.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonMPRN",LR_AUTO);

	lr_start_transaction("SelectAddress");

	web_add_header("xhrseqnum", 
		"2");

	lr_think_time(27);

	web_submit_data("maximo.jsp_15", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx576[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx576[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("SelectAddress",LR_AUTO);

	lr_start_transaction("ClkonSchedule");

	lr_start_transaction("ReturntoValue");

	web_add_header("xhrseqnum", 
		"3");

	lr_think_time(43);

	web_submit_data("maximo.jsp_16", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx282", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx282\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Emergency Work Order Tracking", 
		LAST);

	web_url("maximo.jsp_17", 
		"URL=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("ReturntoValue",LR_AUTO);

	lr_start_transaction("ClkonChangeStatus");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"4");

	lr_think_time(35);

	web_submit_data("maximo.jsp_18", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2245", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown_over.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonChangeStatus",LR_AUTO);

	lr_start_transaction("SelectNewStatus");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_19", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2905", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2906\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"3");

	web_submit_data("maximo.jsp_20", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2905", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_FSCH_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("SelectNewStatus",LR_AUTO);

	lr_start_transaction("ClkonOk");

	web_add_header("xhrseqnum", 
		"4");

	lr_think_time(16);

	web_submit_data("maximo.jsp_21", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2960\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/progressbar.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"5");

	web_submit_data("maximo.jsp_22", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"6");

	web_submit_data("maximo.jsp_23", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"7");

	web_submit_data("maximo.jsp_24", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"8");

	web_submit_data("maximo.jsp_25", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"9");

	web_submit_data("maximo.jsp_26", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_reg_find("Text=3,901,748,207", 
		LAST);

	web_add_header("xhrseqnum", 
		"10");

	web_submit_data("maximo.jsp_27", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonOk",LR_AUTO);

	lr_start_transaction("Logout");

	web_add_header("xhrseqnum", 
		"11");

	lr_think_time(30);

	web_submit_data("maximo.jsp_28", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=265", ENDITEM, 
		"Name=csrftoken", "Value=gc4p438j5hqvsqqv4bqepi5rad", ENDITEM, 
		"Name=currentfocus", "Value=mx57", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx57\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"gc4p438j5hqvsqqv4bqepi5rad\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Welcome to Maximo Project UAT", 
		LAST);

	web_url("logout.jsp", 
		"URL=http://porud755/maximo/webclient/login/logout.jsp?uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=265&csrftoken=gc4p438j5hqvsqqv4bqepi5rad", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	return 0;
}