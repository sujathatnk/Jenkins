Action()
{

	web_reg_find("Text=Welcome to Maximo Project UAT", 
		LAST);

	web_url("login.jsp", 
		"URL=http://porud755/maximo/webclient/login/login.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/ge_login_dialog_bkgnd.png", ENDITEM, 
		"Url=images/ge_login_bkgnd.jpg", ENDITEM, 
		"Url=images/ge_bkgnd.png", ENDITEM, 
		"Url=images/ge_login_txtbox.png", ENDITEM, 
		"Url=images/buttonEnabled_tiv.png", ENDITEM, 
		"Url=images/buttonHover_tiv.png", ENDITEM, 
		LAST);

	lr_start_transaction("Login");

	web_reg_find("Text=Start Center", 
		LAST);

	lr_think_time(6);

	web_submit_data("login", 
		"Action=http://porud755/maximo/ui/login", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=allowinsubframe", "Value=null", ENDITEM, 
		"Name=mobile", "Value=false", ENDITEM, 
		"Name=login", "Value=jsp", ENDITEM, 
		"Name=loginstamp", "Value=1524735067789", ENDITEM, 
		"Name=username", "Value=SP51532", ENDITEM, 
		"Name=password", "Value=Deepya!1", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/css/extended.css", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/row.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/sub_row.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/designer/formtabon_selected.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/off.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tabs/over.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tb_button_highlight.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/edited.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/error.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/menusub.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/working.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/warning.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/smartfill.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/async/question.png", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/layers/mbs/popuplayer.js", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/wait.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/ibm_logo_white.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/dialogs/drag_header_middle.gif", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/number.js", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/fx.js", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/fx/Toggler.js", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/resources/blank.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_setup.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/blank.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_change.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_financial.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_asset.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_contract.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_configItems.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_plans.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_inventor.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_int.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_pm.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_security.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_purchase.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_ssdr.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_release.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_sla.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_sd.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_util.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_wo.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/modimg_taskMgmt.gif", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/menuback.png", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menus/item_over.gif", ENDITEM, 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_start_transaction("ClkonGoTo");

	lr_end_transaction("ClkonGoTo",LR_AUTO);

	lr_start_transaction("WorkOrder");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("_QM_Try", 
		"1");

	web_add_header("pageseqnum", 
		"1");

	web_add_header("xhrseqnum", 
		"1");

	lr_think_time(15);

	web_submit_data("maximo.jsp", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx45", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"changeapp\",\"targetId\":\"mx45\",\"value\":\"EMGWOTRACK\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	web_reg_find("Text=Emergency Work Order Tracking", 
		LAST);

	web_url("ui", 
		"URL=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbarsep.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_lcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_rcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_filterRow_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/table_columnHeader_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	lr_end_transaction("WorkOrder",LR_AUTO);

	lr_start_transaction("ClkonNewWO");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	lr_think_time(22);

	web_submit_data("maximo.jsp_2", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx527", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx314\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/required.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_attachments.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/required_label.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_longdescription_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/cb_checked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/cb_uncheckedreadonly.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_date_time.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/cb_unchecked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/layers/mbs/calendar.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/islamic.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_lookup_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonNewWO",LR_AUTO);

	lr_start_transaction("JobType");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_3", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx1025", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1026\",\"value\":\"XJOBTYPE\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_nextdown_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_download.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_next_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	lr_end_transaction("JobType",LR_AUTO);

	lr_start_transaction("SelectJobtype");

	web_add_header("xhrseqnum", 
		"3");

	lr_think_time(18);

	web_submit_data("maximo.jsp_4", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx1751", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx1751\",\"value\":\"ESC\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"},{\"type\":\"filterrows\",\"targetId\":\"mx1698\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/qf_clear.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"4");

	lr_think_time(5);

	web_submit_data("maximo.jsp_5", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx1793[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1793[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("SelectJobtype",LR_AUTO);

	lr_start_transaction("JobPriority");

	web_add_header("xhrseqnum", 
		"5");

	lr_think_time(16);

	web_submit_data("maximo.jsp_6", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx1274", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1275\",\"value\":\"XJOBPRIORITY\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("JobPriority",LR_AUTO);

	lr_start_transaction("SelectValue");

	web_add_header("xhrseqnum", 
		"6");

	lr_think_time(15);

	web_submit_data("maximo.jsp_7", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx1973", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx1973\",\"value\":\"P\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"},{\"type\":\"filterrows\",\"targetId\":\"mx1920\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"7");

	lr_think_time(6);

	web_submit_data("maximo.jsp_8", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2015[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2015[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_date_time_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en-gb/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	lr_end_transaction("SelectValue",LR_AUTO);

	lr_start_transaction("Schedule");

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("blank.html", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/resources/blank.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarYearLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/titleBar.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarDayLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteRoundedIconsSmall.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteArrows.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/buttonEnabled.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"8");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	lr_think_time(6);

	web_custom_request("maximo.jsp_9", 
		"URL=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h&currentfocus=mx1162&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22mx1162%22%2C%22value%22%3A%2227%2F04%2F2018%2015%3A00%3A00%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%2227%2F04%2F2018%2015%3A00%3A00%22%2C%22csrftokenholder%22%3A%22cigf0i1bef9vfuj5hu8qrfev5h%22%7D%5D", 
		LAST);

	lr_end_transaction("Schedule",LR_AUTO);

	lr_start_transaction("EndSchedule");

	web_add_header("xhrseqnum", 
		"9");

	lr_think_time(36);

	web_custom_request("maximo.jsp_10", 
		"URL=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h&currentfocus=mx1170&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22mx1170%22%2C%22value%22%3A%2230%2F04%2F2018%2015%3A30%3A00%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%2230%2F04%2F2018%2015%3A30%3A00%22%2C%22csrftokenholder%22%3A%22cigf0i1bef9vfuj5hu8qrfev5h%22%7D%5D", 
		LAST);

	lr_end_transaction("EndSchedule",LR_AUTO);

	lr_start_transaction("ClkonAddress");

	web_add_header("xhrseqnum", 
		"10");

	lr_think_time(15);

	web_submit_data("maximo.jsp_11", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx1170", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx297\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_filter_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/qf_find_disabled.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonAddress",LR_AUTO);

	lr_start_transaction("ClkonNewRow");

	web_add_header("xhrseqnum", 
		"11");

	lr_think_time(14);

	web_submit_data("maximo.jsp_12", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2187", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2187\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_row_select.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/img_menu_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonNewRow",LR_AUTO);

	lr_start_transaction("ClkonMPRN");

	web_add_header("xhrseqnum", 
		"12");

	web_submit_data("maximo.jsp_13", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2245", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2246\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/menu_icon_link.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonMPRN",LR_AUTO);

	lr_start_transaction("ClkonGoToMeterPoint");

	web_add_header("xhrseqnum", 
		"13");

	lr_think_time(15);

	web_submit_data("maximo.jsp_14", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2245", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_mainrec_menus\",\"value\":\"normal1\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Meter Point", 
		LAST);

	web_url("maximo.jsp_15", 
		"URL=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonGoToMeterPoint",LR_AUTO);

	lr_start_transaction("ProvideCountry");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"3");

	lr_think_time(19);

	web_submit_data("maximo.jsp_16", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx538", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx538\",\"value\":\"LONDON\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"},{\"type\":\"filterrows\",\"targetId\":\"mx327\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/btn_addtobookmarks.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	lr_end_transaction("ProvideCountry",LR_AUTO);

	lr_start_transaction("ProvideMPRN");

	web_add_header("xhrseqnum", 
		"2");

	lr_think_time(31);

	web_submit_data("maximo.jsp_17", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx454", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx454\",\"value\":\"546,431,208\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"},{\"type\":\"filterrows\",\"targetId\":\"mx327\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ProvideMPRN",LR_AUTO);

	lr_start_transaction("ClkonReturnValue");

	web_add_header("xhrseqnum", 
		"3");

	lr_think_time(27);

	web_submit_data("maximo.jsp_18", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx282", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx282\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Emergency Work Order Tracking", 
		LAST);

	web_url("maximo.jsp_19", 
		"URL=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("ClkonReturnValue",LR_AUTO);

	lr_start_transaction("ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"4");

	lr_think_time(21);

	web_submit_data("maximo.jsp_20", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2245", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown_over.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonChangestatus",LR_AUTO);

	lr_start_transaction("Changestatus");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_21", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2905", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2906\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"3");

	web_submit_data("maximo.jsp_22", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2905", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_FSCH_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Changestatus",LR_AUTO);

	lr_start_transaction("Clkok");

	web_add_header("xhrseqnum", 
		"4");

	lr_think_time(9);

	web_submit_data("maximo.jsp_23", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2960\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		EXTRARES, 
		"Url=../webclient/skins-20170809-1350/tivoli09/images/progressbar.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"5");

	web_submit_data("maximo.jsp_24", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"6");

	web_submit_data("maximo.jsp_25", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"7");

	web_submit_data("maximo.jsp_26", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"8");

	web_submit_data("maximo.jsp_27", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2960", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=1", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Clkok",LR_AUTO);

	lr_start_transaction("ClkSave");

	web_reg_find("Text=546,431,208", 
		LAST);

	web_add_header("xhrseqnum", 
		"9");

	lr_think_time(20);

	web_submit_data("maximo.jsp_28", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx2245", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx316\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkSave",LR_AUTO);

	lr_start_transaction("Logout");

	web_add_header("xhrseqnum", 
		"10");

	lr_think_time(18);

	web_submit_data("maximo.jsp_29", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=uisessionid", "Value=18", ENDITEM, 
		"Name=csrftoken", "Value=cigf0i1bef9vfuj5hu8qrfev5h", ENDITEM, 
		"Name=currentfocus", "Value=mx57", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx57\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"cigf0i1bef9vfuj5hu8qrfev5h\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Welcome to Maximo Project UAT", 
		LAST);

	web_url("logout.jsp", 
		"URL=http://porud755/maximo/webclient/login/logout.jsp?uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid=18&csrftoken=cigf0i1bef9vfuj5hu8qrfev5h", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	return 0;
}