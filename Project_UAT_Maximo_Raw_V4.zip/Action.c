Action()
{
  int i,nCount;
  
  char * Address_Values;
  
  char * Address_Count;
  
  char szparamName[100];
  
  lr_start_transaction("Launch");

	web_reg_find("Text=Welcome to Maximo Project UAT", 
		LAST);

/*Correlation comment - Do not change!  Original value='1524735067789' Name ='loginstamp' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=loginstamp",
		"TagName=input",
		"Extract=value",
		"Name=loginstamp",
		"Id=loginstamp",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/login.jsp*",
		LAST);

	web_url("login.jsp", 
		"URL=http://porud755/maximo/webclient/login/login.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/ge_login_dialog_bkgnd.png", ENDITEM, 
		"Url=images/ge_login_bkgnd.jpg", ENDITEM, 
		"Url=images/ge_bkgnd.png", ENDITEM, 
		"Url=images/ge_login_txtbox.png", ENDITEM, 
		"Url=images/buttonEnabled_tiv.png", ENDITEM, 
		"Url=images/buttonHover_tiv.png", ENDITEM, 
		LAST);
		
		lr_end_transaction("Launch", LR_AUTO);

		
		lr_think_time(5);

	lr_start_transaction("Login");

	web_reg_find("Text=Start Center", 
		LAST);

	

/*Correlation comment - Do not change!  Original value='cigf0i1bef9vfuj5hu8qrfev5h' Name ='csrftoken' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=csrftoken",
		"LB=csrftoken=",
		"RB=\";\n\t\t\tvar XHRACTION ",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/login*",
		LAST);
		
		web_reg_save_param("uisessionid","LB=maximo.jsp?uisessionid=","RB=&",LAST);

/*Correlation comment - Do not change!  Original value='mx57' Name ='currentfocus_4' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=currentfocus_4",
		"LB= id=\"",
		"RB=_holder",
		"Ordinal=6",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/login*",
		LAST);

	web_submit_data("login",
		"Action=http://porud755/maximo/ui/login",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/webclient/login/login.jsp",
		"Snapshot=t2.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=allowinsubframe", "Value=null", ENDITEM,
		"Name=mobile", "Value=false", ENDITEM,
		"Name=login", "Value=jsp", ENDITEM,
		"Name=loginstamp", "Value={loginstamp}", ENDITEM,
		"Name=username", "Value=SP51532", ENDITEM,
		"Name=password", "Value=Deepya!1", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/css/extended.css", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/row.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/sub_row.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/designer/formtabon_selected.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/off.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tabs/over.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tb_button_highlight.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/edited.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/error.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/menusub.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/working.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/warning.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/smartfill.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/async/question.png", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/layers/mbs/popuplayer.js", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/wait.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/ibm_logo_white.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/dialogs/drag_header_middle.gif", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/number.js", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/fx.js", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/fx/Toggler.js", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/resources/blank.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_setup.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/blank.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_change.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_financial.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_asset.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_contract.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_configItems.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_plans.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_inventor.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_int.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_pm.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_security.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_purchase.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_ssdr.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_release.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_sla.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_sd.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_util.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_wo.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/modimg_taskMgmt.gif", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/menuback.png", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menus/item_over.gif", ENDITEM,
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("WorkOrder");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("_QM_Try", 
		"1");

	web_add_header("pageseqnum", 
		"1");

	web_add_header("xhrseqnum", 
		"1");

	


	web_submit_data("maximo.jsp",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/login",
		"Snapshot=t3.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx45", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"changeapp\",\"targetId\":\"mx45\",\"value\":\"EMGWOTRACK\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_reg_find("Text=Emergency Work Order Tracking", 
		LAST);

/*Correlation comment - Do not change!  Original value='mx282' Name ='currentfocus_5' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=currentfocus_5",
		"LB= id=\"",
		"RB=\" ctype",
		"Ordinal=15",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ui/*",
		LAST);

/*Correlation comment - Do not change!  Original value='mx454' Name ='currentfocus_6' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=currentfocus_6",
		"LB= id=\"",
		"RB=\"   width",
		"Ordinal=12",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ui/*",
		LAST);

/*Correlation comment - Do not change!  Original value='mx527' Name ='currentfocus_7' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=currentfocus_7",
		"LB= id=\"",
		"RB=_holder",
		"Ordinal=72",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/ui/*",
		LAST);

	web_url("ui",
		"URL=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/login",
		"Snapshot=t4.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbarsep.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_lcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_toolbar_rcap.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_filterRow_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/table_columnHeader_bkg.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("WorkOrder",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("ClkonNewWO");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");


	
	web_reg_save_param("WorkOrder","LB=title=\"Work Order: ","RB=\" value=\"",LAST);
	
	

	web_submit_data("maximo.jsp_2",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t5.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_7}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx314\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/required.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_attachments.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/required_label.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_longdescription_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/cb_checked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/cb_uncheckedreadonly.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_date_time.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/cb_unchecked.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/layers/mbs/calendar.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/islamic.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_lookup_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("ClkonNewWO",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("JobType");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_3",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t6.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1025", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1026\",\"value\":\"XJOBTYPE\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_nextdown_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_download.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_next_on.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("JobType",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("SelectJobtype");

	web_add_header("xhrseqnum", 
		"3");

	

	web_submit_data("maximo.jsp_4",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t7.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1751", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx1751\",\"value\":\"ESC\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"{csrftoken}\"},{\"type\":\"filterrows\",\"targetId\":\"mx1698\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/qf_clear.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"4");

	

/*Correlation comment - Do not change!  Original value='mx1025' Name ='currentfocus_3' Type ='ResponseBased'*/
	web_reg_save_param_xpath(
		"ParamName=currentfocus_3",
		"QueryString=/server_response/compvalue[2]/@id",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_submit_data("maximo.jsp_5",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t8.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1793[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1793[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("SelectJobtype",LR_AUTO);
	
	lr_think_time(5);


	lr_start_transaction("JobPriority");

	web_add_header("xhrseqnum", 
		"5");

	

	web_submit_data("maximo.jsp_6",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t9.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1274", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1275\",\"value\":\"XJOBPRIORITY\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("JobPriority",LR_AUTO);
	
	lr_think_time(5);


	lr_start_transaction("SelectValue");

	web_add_header("xhrseqnum", 
		"6");


	web_submit_data("maximo.jsp_7",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t10.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1973", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx1973\",\"value\":\"P\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"{csrftoken}\"},{\"type\":\"filterrows\",\"targetId\":\"mx1920\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"7");


/*Correlation comment - Do not change!  Original value='mx1274' Name ='currentfocus_2' Type ='ResponseBased'*/
	web_reg_save_param_xpath(
		"ParamName=currentfocus_2",
		"QueryString=/server_response/compvalue[6]/@id",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_submit_data("maximo.jsp_8",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t11.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2015[R:0]", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2015[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_date_time_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en-gb/gregorian.js", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("SelectValue",LR_AUTO);
	
	lr_think_time(5);


	lr_start_transaction("Schedule");

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

/*	web_url("blank.html",
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/resources/blank.html",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t12.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarYearLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/titleBar.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/calendarDayLabel.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteRoundedIconsSmall.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/spriteArrows.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/images/buttonEnabled.png", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);*/

	web_add_header("xhrseqnum", 
		"8");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");


	web_custom_request("maximo.jsp_9",
		"URL=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t13.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded;charset=UTF-8",
		"Body=uisessionid={uisessionid}&csrftoken={csrftoken}&currentfocus=mx1162&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22mx1162%22%2C%22value%22%3A%22{Date}%2F{Month}%2F2018%2015%3A00%3A00%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%22{Date}%2F{Month}%2F2018%2015%3A00%3A00%22%2C%22csrftokenholder%22%3A%22{csrftoken}%22%7D%5D",
		LAST);

	lr_end_transaction("Schedule",LR_AUTO);
	
	lr_think_time(5);


	lr_start_transaction("EndSchedule");

	web_add_header("xhrseqnum", 
		"9");



	web_custom_request("maximo.jsp_10",
		"URL=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t14.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded;charset=UTF-8",
		"Body=uisessionid={uisessionid}&csrftoken={csrftoken}&currentfocus=mx1170&scrollleftpos=0&scrolltoppos=0&requesttype=ASYNC&responsetype=text%2Fxml&events=%5B%7B%22type%22%3A%22setvalue%22%2C%22targetId%22%3A%22mx1170%22%2C%22value%22%3A%22{End}%2F{EndMonth}%2F2018%2015%3A30%3A00%22%2C%22requestType%22%3A%22ASYNC%22%2C%22processvalue%22%3A%22{End}%2F04%2F2018%2015%3A30%3A00%22%2C%22csrftokenholder%22%3A%22{csrftoken}%22%7D%5D",
		LAST);

	lr_end_transaction("EndSchedule",LR_AUTO);
	
	lr_think_time(5);


	lr_start_transaction("ClkonAddress");

	web_add_header("xhrseqnum", 
		"10");

	

	web_submit_data("maximo.jsp_11",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t15.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx1170", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx297\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/tablebtn_filter_off.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/qf_find_disabled.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("ClkonAddress",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("ClkonNewRow");

	web_add_header("xhrseqnum", 
		"11");



	web_submit_data("maximo.jsp_12",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t16.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2187", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2187\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_row_select.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/img_menu_over.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("ClkonNewRow",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("ClkonMPRN");

	web_add_header("xhrseqnum", 
		"12");

	web_submit_data("maximo.jsp_13",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t17.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2245", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2246\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/menu_icon_link.gif", "Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("ClkonMPRN",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("ClkonGoToMeterPoint");

	web_add_header("xhrseqnum", 
		"13");

	
	web_submit_data("maximo.jsp_14",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t18.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2245", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_mainrec_menus\",\"value\":\"normal1\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Meter Point", 
		LAST);

/*Correlation comment - Do not change!  Original value='mx538' Name ='currentfocus_8' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=currentfocus_8",
		"LB= id=\"",
		"RB=_holder",
		"Ordinal=75",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/maximo.jsp*",
		LAST);

	web_url("maximo.jsp_15",
		"URL=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t19.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_bkg_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/banner_swoosh_applink.png", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("ClkonGoToMeterPoint",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("ProvideCountry");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"3");

	//:5px;;cursor:pointer;;;;" title="8,814,167,601">
	
	
	web_reg_save_param("Address","LB=5px;;cursor:pointer;;;;\" title=\"","RB=\">","ORD=All",LAST);
	
	//web_reg_save_param_regexp( "ParamName=Address", "RegExp=:5px;;cursor:pointer;;;;\" title=\"\\*"\">", LAST);
	
	
	
	
	//Address_Values = lr_paramarr_random("Address");
		
		//web_convert_param("Address_1", "SourceString={Address}", "SourceEncoding=HTML", "TargetEncoding=URL", LAST); 
		
		
		nCount=atoi(lr_eval_string("{Address_Count}"));
		for (i=1;i<=nCount;i++)
		{
			sprintf(szparamName, "{Address_%d}",i);
			
			lr_output_message("Value of %s:%s",szparamName,lr_eval_string(szparamName));
		}	

	web_submit_data("maximo.jsp_16",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t20.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_8}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"{currentfocus_8}\",\"value\":\"LONDON\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"{csrftoken}\"},{\"type\":\"filterrows\",\"targetId\":\"mx327\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/btn_addtobookmarks.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("ProvideCountry",LR_AUTO);
		lr_think_time(5);

	lr_start_transaction("ProvideMPRN");

	web_add_header("xhrseqnum", 
		"2");

	
	
	//web_reg_find("Text=546,431,208",LAST);

	web_submit_data("maximo.jsp_17",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t21.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_6}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"{currentfocus_6}\",\"value\":\"{Address_i}\",\"requestType\":\"ASYNC\",\"csrftokenholder\":\"{csrftoken}\"},{\"type\":\"filterrows\",\"targetId\":\"mx327\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);
//8,814,167,60
	lr_end_transaction("ProvideMPRN",LR_AUTO);
	
	lr_think_time(5);
	lr_start_transaction("ClkonReturnValue");

	web_add_header("xhrseqnum", 
		"3");

	

	web_submit_data("maximo.jsp_18",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t22.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_5}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{currentfocus_5}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Emergency Work Order Tracking", 
		LAST);

/*Correlation comment - Do not change!  Original value='mx2245' Name ='currentfocus' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=currentfocus",
		"LB= for=\"",
		"RB=\" title",
		"Ordinal=5",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

/*Correlation comment - Do not change!  Original value='mx2187' Name ='currentfocus_1' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=currentfocus_1",
		"LB= id=\"",
		"RB=_holder",
		"Ordinal=61",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("maximo.jsp_19",
		"URL=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=gotoapp&value=XMPRN&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t23.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("ClkonReturnValue",LR_AUTO);
	
		lr_think_time(5);

	lr_start_transaction("ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"4");



	web_submit_data("maximo.jsp_20",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t24.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/IE_dropdown_over.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	lr_end_transaction("ClkonChangestatus",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Changestatus");

	web_add_header("xhrseqnum", 
		"2");

	web_submit_data("maximo.jsp_21",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t25.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2905", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2906\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"3");

	web_submit_data("maximo.jsp_22",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t26.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2905", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_FSCH_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("Changestatus",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Clkok");

	web_add_header("xhrseqnum", 
		"4");

	
	
	web_reg_find("Text=Please wait","SaveCount=currstatus", "Search=All",LAST);

	
	web_submit_data("maximo.jsp_23",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t27.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2960", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2960\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		EXTRARES,
		"URL=../webclient/skins-20170809-1350/tivoli09/images/progressbar.gif", "Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}", ENDITEM,
		LAST);

	
	
	if ((atoi(lr_eval_string("{currstatus}"))>0))
		
		
	{
		do
{
			i++;
			
	
			
    web_reg_find("Text=Status change(s) completed successfully","SaveCount=currstatus", "Search=All",LAST);
    

    
    
    
	web_add_header("xhrseqnum", 
		"5");

	web_submit_data("maximo.jsp_24",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t28.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2960", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);
    

	/*web_add_header("xhrseqnum", 
		"6");

	web_submit_data("maximo.jsp_25",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t29.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2960", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"7");

	web_submit_data("maximo.jsp_26",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t{End}.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2960", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);

	web_add_header("xhrseqnum", 
		"8");

	web_submit_data("maximo.jsp_{Date}",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t31.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value=mx2960", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=1", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM,
		LAST);*/
	
	 }	while(atoi(lr_eval_string("{currstatus}"))==1);

	}
	
	
/*if (atoi(lr_eval_string("{currstatus1}")) > 0){
��������lr_output_message("Order successful");
��������}
���� else{
��������lr_error_message("Order failed");
��������return(0);
���� }*/
	
	

	lr_end_transaction("Clkok",LR_AUTO);
	
	lr_think_time(5);

	/*lr_start_transaction("ClkSave");


	
	web_reg_find("Text=Record has been saved",LAST);

	web_add_header("xhrseqnum", 
		"9");

	lr_think_time(20);

	web_submit_data("maximo.jsp_28",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t32.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx316\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	lr_end_transaction("ClkSave",LR_AUTO);*/

	lr_start_transaction("Logout");

	web_add_header("xhrseqnum", 
		"10");



	web_submit_data("maximo.jsp_29",
		"Action=http://porud755/maximo/ui/maximo.jsp",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/xml",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t33.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=uisessionid", "Value={uisessionid}", ENDITEM,
		"Name=csrftoken", "Value={csrftoken}", ENDITEM,
		"Name=currentfocus", "Value={currentfocus_4}", ENDITEM,
		"Name=scrollleftpos", "Value=0", ENDITEM,
		"Name=scrolltoppos", "Value=0", ENDITEM,
		"Name=requesttype", "Value=SYNC", ENDITEM,
		"Name=responsetype", "Value=text/xml", ENDITEM,
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"{currentfocus_4}\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"{csrftoken}\"}]", ENDITEM,
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_reg_find("Text=Welcome to Maximo Project UAT", 
		LAST);

	web_url("logout.jsp",
		"URL=http://porud755/maximo/webclient/login/logout.jsp?uisessionid={uisessionid}&csrftoken={csrftoken}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://porud755/maximo/ui/maximo.jsp?event=render&targetid=emgwotrack&value=rerender&uisessionid={uisessionid}&csrftoken={csrftoken}",
		"Snapshot=t34.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	return 0;
}