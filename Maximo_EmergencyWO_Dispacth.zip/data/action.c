Action()
{

	web_url("login.jsp", 
		"URL=http://porud755/maximo/webclient/login/login.jsp", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("login.css", 
		"URL=http://porud755/maximo/webclient/login/css/login.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("tivoli_brandmark.png", 
		"URL=http://porud755/maximo/webclient/login/images/tivoli_brandmark.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("login.css_2", 
		"URL=http://porud755/maximo/webclient/login/css/tivoli09/login.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("ibm-logo-white.gif", 
		"URL=http://porud755/maximo/webclient/login/images/ibm-logo-white.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("mx_icon.png", 
		"URL=http://porud755/maximo/webclient/login/images/mx_icon.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("maximo-icon.ico", 
		"URL=http://porud755/maximo/webclient/images/maximo-icon.ico", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t12.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("ge_login_dialog_bkgnd.png", 
		"URL=http://porud755/maximo/webclient/login/images/ge_login_dialog_bkgnd.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("ge_login_bkgnd.jpg", 
		"URL=http://porud755/maximo/webclient/login/images/ge_login_bkgnd.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("ge_bkgnd.png", 
		"URL=http://porud755/maximo/webclient/login/images/ge_bkgnd.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t9.inf", 
		LAST);

	web_url("ge_login_txtbox.png", 
		"URL=http://porud755/maximo/webclient/login/images/ge_login_txtbox.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("buttonEnabled_tiv.png", 
		"URL=http://porud755/maximo/webclient/login/images/buttonEnabled_tiv.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t11.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(22);

	lr_start_transaction("Login");

	web_submit_data("login", 
		"Action=http://porud755/maximo/ui/login", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/webclient/login/login.jsp", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=allowinsubframe", "Value=null", ENDITEM, 
		"Name=mobile", "Value=false", ENDITEM, 
		"Name=login", "Value=jsp", ENDITEM, 
		"Name=loginstamp", "Value=1526734918012", ENDITEM, 
		"Name=username", "Value=SP51532", ENDITEM, 
		"Name=password", "Value=Deepya!1", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("dojo.css", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/resources/dojo.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("ellipsis.css", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojox/html/resources/ellipsis.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("maximo.css", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/css/maximo.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("tundra.css", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dijit/themes/tundra/tundra.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t17.inf", 
		LAST);

	web_url("constants.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/constants.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t18.inf", 
		LAST);

	web_url("deprecated.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/deprecated.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t19.inf", 
		LAST);

	web_url("prototype.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/prototype.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t20.inf", 
		LAST);

	web_url("menus.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/menus.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t21.inf", 
		LAST);

	web_url("browser_library.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/browser_library.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t22.inf", 
		LAST);

	web_url("library.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/library.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t23.inf", 
		LAST);

	web_url("navsection.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/navsection.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t24.inf", 
		LAST);

	web_url("library_ex.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/library_ex.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t25.inf", 
		LAST);

	web_url("skinlibrary.js", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/js/skinlibrary.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t26.inf", 
		LAST);

	web_url("designer.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/designer.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t27.inf", 
		LAST);

	web_url("async.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/async.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t29.inf", 
		LAST);

	web_url("wfdesign.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/wfdesign.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t30.inf", 
		LAST);

	web_url("dataproxy.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/dataproxy.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t31.inf", 
		LAST);

	web_url("sessiontimer.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/sessiontimer.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t32.inf", 
		LAST);

	web_url("dojo.js", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/dojo.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t45.inf", 
		LAST);

	web_url("window.js", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/window.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t47.inf", 
		LAST);

	web_url("dojo_library.js", 
		"URL=http://porud755/maximo/webclient/javascript/tpae-20170809-1350/dojo_library.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t48.inf", 
		LAST);

	web_url("appimg_startcntr.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/appimg_startcntr.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t49.inf", 
		LAST);

	web_url("btn_bboard.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/btn_bboard.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t50.inf", 
		LAST);

	web_url("information.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/information.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t51.inf", 
		LAST);

	web_url("btn_reporting.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/btn_reporting.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t52.inf", 
		LAST);

	web_url("btn_profile.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/btn_profile.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t53.inf", 
		LAST);

	web_url("gotoarrow.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/gotoarrow.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t54.inf", 
		LAST);

	web_url("btn_startcenter.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/btn_startcenter.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t55.inf", 
		LAST);

	web_url("btn_signout.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/btn_signout.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t56.inf", 
		LAST);

	web_url("btn_deletetemplate.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/btn_deletetemplate.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t58.inf", 
		LAST);

	web_url("btn_savetemplate.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/btn_savetemplate.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t59.inf", 
		LAST);

	web_url("btn_cancelchanges.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/btn_cancelchanges.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t60.inf", 
		LAST);

	web_url("btn_changecontent.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/btn_changecontent.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t61.inf", 
		LAST);

	web_url("btn_help.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/btn_help.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t62.inf", 
		LAST);

	web_url("icon_details.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/icon_details.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t63.inf", 
		LAST);

	web_url("blank.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/blank.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t68.inf", 
		LAST);

	web_url("maximo-icon.ico_2", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/maximo-icon.ico", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t74.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_url("extended.css", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/css/extended.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t28.inf", 
		LAST);

	web_concurrent_start(NULL);

	web_url("row.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tabs/row.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t33.inf", 
		LAST);

	web_url("off.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tabs/off.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t34.inf", 
		LAST);

	web_url("over.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tabs/over.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t35.inf", 
		LAST);

	web_url("sub_row.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tabs/sub_row.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t36.inf", 
		LAST);

	web_url("tb_button_highlight.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tb_button_highlight.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t37.inf", 
		LAST);

	web_url("formtabon_selected.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/designer/formtabon_selected.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t38.inf", 
		LAST);

	web_url("menusub.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/menus/menusub.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t39.inf", 
		LAST);

	web_url("edited.png", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/async/edited.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t40.inf", 
		LAST);

	web_url("working.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/async/working.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t41.inf", 
		LAST);

	web_url("error.png", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/async/error.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t42.inf", 
		LAST);

	web_url("warning.png", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/async/warning.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t43.inf", 
		LAST);

	web_url("question.png", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/async/question.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t44.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_url("smartfill.png", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/async/smartfill.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t46.inf", 
		LAST);

	web_url("popuplayer.js", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/layers/mbs/popuplayer.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t57.inf", 
		LAST);

	web_concurrent_start(NULL);

	web_url("banner_bkg.png", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/banner_bkg.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t64.inf", 
		LAST);

	web_url("banner_swoosh.png", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/banner_swoosh.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t65.inf", 
		LAST);

	web_url("ibm_logo_white.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/ibm_logo_white.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t66.inf", 
		LAST);

	web_url("drag_header_middle.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/dialogs/drag_header_middle.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t67.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("wait.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/wait.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t69.inf", 
		LAST);

	web_url("number.js", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/number.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t70.inf", 
		LAST);

	web_url("fx.js", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/fx.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t71.inf", 
		LAST);

	web_url("Toggler.js", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/fx/Toggler.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t72.inf", 
		LAST);

	web_url("blank.gif_2", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/resources/blank.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t73.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("Login",LR_AUTO);

	lr_start_transaction("ClkonGotoWorkOrder");

	web_concurrent_start(NULL);

	web_url("blank.gif_3", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/menus/blank.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t75.inf", 
		LAST);

	web_url("modimg_setup.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_setup.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t76.inf", 
		LAST);

	web_url("modimg_asset.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_asset.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t77.inf", 
		LAST);

	web_url("modimg_change.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_change.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t78.inf", 
		LAST);

	web_url("modimg_contract.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_contract.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t79.inf", 
		LAST);

	web_url("modimg_inventor.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_inventor.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t80.inf", 
		LAST);

	web_url("modimg_configItems.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_configItems.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t81.inf", 
		LAST);

	web_url("modimg_financial.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_financial.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t82.inf", 
		LAST);

	web_url("modimg_int.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_int.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t83.inf", 
		LAST);

	web_url("modimg_pm.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_pm.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t84.inf", 
		LAST);

	web_url("modimg_purchase.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_purchase.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t85.inf", 
		LAST);

	web_url("modimg_plans.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_plans.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t86.inf", 
		LAST);

	web_url("modimg_release.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_release.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t87.inf", 
		LAST);

	web_url("modimg_security.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_security.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t88.inf", 
		LAST);

	web_url("modimg_ssdr.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_ssdr.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t89.inf", 
		LAST);

	web_url("modimg_sd.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_sd.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t90.inf", 
		LAST);

	web_url("modimg_sla.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_sla.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t91.inf", 
		LAST);

	web_url("modimg_util.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_util.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t92.inf", 
		LAST);

	web_url("menuback.png", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/menus/menuback.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t93.inf", 
		LAST);

	web_url("modimg_taskMgmt.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_taskMgmt.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t94.inf", 
		LAST);

	web_url("item_over.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/menus/item_over.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t95.inf", 
		LAST);

	web_url("modimg_wo.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/modimg_wo.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t96.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("_QM_Try", 
		"1");

	web_add_header("pageseqnum", 
		"1");

	web_add_header("xhrseqnum", 
		"1");

	lr_think_time(33);

	web_submit_data("maximo.jsp", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t97.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx45", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"changeapp\",\"targetId\":\"mx45\",\"value\":\"EMGWOTRACK\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_url("ui", 
		"URL=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/login", 
		"Snapshot=t98.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("appimg_wotrack.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/appimg_wotrack.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t99.inf", 
		LAST);

	web_url("nav_icon_save.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/nav_icon_save.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t100.inf", 
		LAST);

	web_url("nav_icon_insertkey.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/nav_icon_insertkey.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t101.inf", 
		LAST);

	web_url("quicksearch.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/quicksearch.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t102.inf", 
		LAST);

	web_url("IE_toolbar_dropdown.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/IE_toolbar_dropdown.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t103.inf", 
		LAST);

	web_url("nav_btn_menuArrow_Search.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/nav_btn_menuArrow_Search.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t105.inf", 
		LAST);

	web_url("nav_icon_clear.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/nav_icon_clear.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t112.inf", 
		LAST);

	web_url("nav_icon_previous.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/nav_icon_previous.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t113.inf", 
		LAST);

	web_url("nav_icon_next.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/nav_icon_next.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t114.inf", 
		LAST);

	web_url("nav_icon_changestatus.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/nav_icon_changestatus.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t115.inf", 
		LAST);

	web_url("nav_icon_createQueryBasedReport.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/nav_icon_createQueryBasedReport.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t116.inf", 
		LAST);

	web_url("nav_icon_route.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/nav_icon_route.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t117.inf", 
		LAST);

	web_url("atb_search.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/atb_search.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t118.inf", 
		LAST);

	web_url("nav_icon_kpi.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/nav_icon_kpi.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t119.inf", 
		LAST);

	web_url("appimg_report.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/appimg_report.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t120.inf", 
		LAST);

	web_url("atb_bookmark.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/atb_bookmark.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t121.inf", 
		LAST);

	web_url("atb_save.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/atb_save.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t122.inf", 
		LAST);

	web_url("atb_popoutmenu.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/atb_popoutmenu.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t123.inf", 
		LAST);

	web_url("tablebtn_divider.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tablebtn_divider.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t124.inf", 
		LAST);

	web_url("tablebtn_filter_on.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tablebtn_filter_on.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t125.inf", 
		LAST);

	web_url("img_arrow_quickfilter.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/img_arrow_quickfilter.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t126.inf", 
		LAST);

	web_url("qf_find.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/qf_find.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t127.inf", 
		LAST);

	web_url("qf_clear_disabled.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/qf_clear_disabled.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t128.inf", 
		LAST);

	web_url("listab_refresh.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/listab_refresh.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t129.inf", 
		LAST);

	web_url("tablebtn_nextup_off.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tablebtn_nextup_off.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t130.inf", 
		LAST);

	web_url("tablebtn_nextdown_off.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tablebtn_nextdown_off.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t131.inf", 
		LAST);

	web_url("tablebtn_next_off.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tablebtn_next_off.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t132.inf", 
		LAST);

	web_url("tablebtn_previous_off.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tablebtn_previous_off.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t133.inf", 
		LAST);

	web_url("tablebtn_download_off.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tablebtn_download_off.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t134.inf", 
		LAST);

	web_url("table_cb_unchecked.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/table_cb_unchecked.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t135.inf", 
		LAST);

	web_url("minimize.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/minimize.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t136.inf", 
		LAST);

	web_url("img_lookup.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/img_lookup.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t137.inf", 
		LAST);

	web_url("img_menu.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/img_menu.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t138.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_url("toolbar_bkg.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbar_bkg.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t104.inf", 
		LAST);

	web_concurrent_start(NULL);

	web_url("table_toolbar_lcap.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/table_toolbar_lcap.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t106.inf", 
		LAST);

	web_url("toolbarsep.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/toolbar/toolbarsep.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t107.inf", 
		LAST);

	web_url("table_toolbar_bkg.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/table_toolbar_bkg.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t108.inf", 
		LAST);

	web_url("table_columnHeader_bkg.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/table_columnHeader_bkg.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t109.inf", 
		LAST);

	web_url("table_toolbar_rcap.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/table_toolbar_rcap.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t110.inf", 
		LAST);

	web_url("table_filterRow_bkg.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/table_filterRow_bkg.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t111.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("ClkonGotoWorkOrder",LR_AUTO);

	lr_start_transaction("ProvideWorkOrder");

	web_add_header("xhrseqnum", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("_QM_Try", 
		"1");

	web_add_auto_header("pageseqnum", 
		"2");

	lr_think_time(32);

	web_submit_data("maximo.jsp_2", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t139.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx93", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"setvalue\",\"targetId\":\"mx93\",\"value\":\"W114594093\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"},{\"type\":\"click\",\"targetId\":\"mx95\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("required.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/required.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t140.inf", 
		LAST);

	web_url("required_label.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/required_label.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t141.inf", 
		LAST);

	web_url("img_longdescription_off.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/img_longdescription_off.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t142.inf", 
		LAST);

	web_url("img_attachments.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/img_attachments.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t143.inf", 
		LAST);

	web_url("cb_checked.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/cb_checked.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t144.inf", 
		LAST);

	web_url("img_date_time.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/img_date_time.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t145.inf", 
		LAST);

	web_url("cb_uncheckedreadonly.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/cb_uncheckedreadonly.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t146.inf", 
		LAST);

	web_url("cb_unchecked.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/cb_unchecked.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t147.inf", 
		LAST);

	web_url("calendar.js", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/layers/mbs/calendar.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t148.inf", 
		LAST);

	web_url("gregorian.js", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/gregorian.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t149.inf", 
		LAST);

	web_url("islamic.js", 
		"URL=http://porud755/maximo/webclient/javascript/dojo-20130903-1504/dojo/cldr/nls/en/islamic.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t150.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("ProvideWorkOrder",LR_AUTO);

	lr_start_transaction("ClkonChangeStatus");

	web_add_header("xhrseqnum", 
		"2");

	lr_think_time(28);

	web_submit_data("maximo.jsp_3", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t151.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx930", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("IE_dropdown.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/IE_dropdown.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t152.inf", 
		LAST);

	web_url("IE_dropdown_over.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/IE_dropdown_over.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t153.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("ClkonChangeStatus",LR_AUTO);

	lr_start_transaction("StatustoDistpatch");

	web_add_header("xhrseqnum", 
		"3");

	lr_think_time(16);

	web_submit_data("maximo.jsp_4", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t154.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1690", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1691\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"4");

	web_submit_data("maximo.jsp_5", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t155.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1690", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_DISPATCH_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("StatustoDistpatch",LR_AUTO);

	lr_start_transaction("ClkOk_Dispatch");

	web_add_header("xhrseqnum", 
		"5");

	lr_think_time(19);

	web_submit_data("maximo.jsp_6", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t156.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1745\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_url("progressbar.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/progressbar.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t157.inf", 
		LAST);

	web_add_header("xhrseqnum", 
		"6");

	web_submit_data("maximo.jsp_7", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t158.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"7");

	web_submit_data("maximo.jsp_8", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t159.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"8");

	web_submit_data("maximo.jsp_9", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t160.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"9");

	web_submit_data("maximo.jsp_10", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t161.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"10");

	web_submit_data("maximo.jsp_11", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t162.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"11");

	web_submit_data("maximo.jsp_12", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t163.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"12");

	web_submit_data("maximo.jsp_13", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t164.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"13");

	web_submit_data("maximo.jsp_14", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t165.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"14");

	web_submit_data("maximo.jsp_15", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t166.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"15");

	web_submit_data("maximo.jsp_16", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t167.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"16");

	web_submit_data("maximo.jsp_17", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t168.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"17");

	web_submit_data("maximo.jsp_18", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t169.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1745", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkOk_Dispatch",LR_AUTO);

	lr_start_transaction("ClkonChangeStatus");

	web_add_header("xhrseqnum", 
		"18");

	lr_think_time(25);

	web_submit_data("maximo.jsp_19", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t170.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx930", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonChangeStatus",LR_AUTO);

	lr_start_transaction("Onsite_status");

	web_add_header("xhrseqnum", 
		"19");

	lr_think_time(28);

	web_submit_data("maximo.jsp_20", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t171.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1875", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1876\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"20");

	web_submit_data("maximo.jsp_21", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t172.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1875", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_ACCEPT_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Onsite_status",LR_AUTO);

	lr_start_transaction("Clkok_Accept");

	web_add_header("xhrseqnum", 
		"21");

	lr_think_time(14);

	web_submit_data("maximo.jsp_22", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t173.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1930", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1930\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"22");

	web_submit_data("maximo.jsp_23", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t174.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1930", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Clkok_Accept",LR_AUTO);

	lr_think_time(22);

	lr_start_transaction("Changedetails");

	web_url("img_lookup_over.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/img_lookup_over.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t175.inf", 
		LAST);

	web_add_header("xhrseqnum", 
		"23");

	web_submit_data("maximo.jsp_24", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t176.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1473", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1474\",\"value\":\"valuelist\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("tablebtn_nextdown_on.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tablebtn_nextdown_on.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t177.inf", 
		LAST);

	web_url("tablebtn_download.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tablebtn_download.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t178.inf", 
		LAST);

	web_url("col_sort_asc.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/col_sort_asc.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t179.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_header("xhrseqnum", 
		"24");

	web_submit_data("maximo.jsp_25", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t180.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx2116[R:1]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2116[R:1]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"25");

	web_submit_data("maximo.jsp_26", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t181.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1481", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1482\",\"value\":\"VALUELIST\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"26");

	web_submit_data("maximo.jsp_27", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t182.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx2297[R:1]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2297[R:1]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"27");

	web_submit_data("maximo.jsp_28", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t183.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1492", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx1493\",\"value\":\"valuelist\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"28");

	web_submit_data("maximo.jsp_29", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t184.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx2478[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2478[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Changedetails",LR_AUTO);

	lr_start_transaction("ClkonCompletion");

	web_add_header("xhrseqnum", 
		"29");

	lr_think_time(27);

	web_submit_data("maximo.jsp_30", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t185.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx1492", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx300\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("tablebtn_filter_off.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/tablebtn_filter_off.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t186.inf", 
		LAST);

	web_url("qf_find_disabled.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/qf_find_disabled.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t187.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("ClkonCompletion",LR_AUTO);

	lr_start_transaction("Smartmeter");

	web_add_header("xhrseqnum", 
		"30");

	lr_think_time(12);

	web_submit_data("maximo.jsp_31", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t188.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx2576", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx2577\",\"value\":\"VALUELIST\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"31");

	web_submit_data("maximo.jsp_32", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t189.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx6911[R:0]", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx6911[R:0]\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Smartmeter",LR_AUTO);

	lr_start_transaction("ClkonChangestatus");

	web_add_header("xhrseqnum", 
		"32");

	lr_think_time(17);

	web_submit_data("maximo.jsp_33", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t190.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx2576", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ClkonChangestatus",LR_AUTO);

	lr_start_transaction("ChangeStatus_COMP");

	web_add_header("xhrseqnum", 
		"33");

	lr_think_time(19);

	web_submit_data("maximo.jsp_34", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t191.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7014", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7015\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"34");

	web_submit_data("maximo.jsp_35", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t192.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7014", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_ONSITE_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"35");

	web_submit_data("maximo.jsp_36", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t193.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7069", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7069\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"36");

	web_submit_data("maximo.jsp_37", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t194.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7069", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("ChangeStatus_COMP",LR_AUTO);

	lr_start_transaction("Clkonchangestatus");

	web_add_header("xhrseqnum", 
		"37");

	lr_think_time(20);

	web_submit_data("maximo.jsp_38", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t195.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx2576", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx328\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_url("img_date_time_over.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/img_date_time_over.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t196.inf", 
		LAST);

	lr_end_transaction("Clkonchangestatus",LR_AUTO);

	lr_start_transaction("Changestatus_COMP");

	web_add_header("xhrseqnum", 
		"38");

	lr_think_time(18);

	web_submit_data("maximo.jsp_39", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t197.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7177", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7178\",\"value\":\"combobox\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"39");

	web_submit_data("maximo.jsp_40", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t198.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7177", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"emgwotrack_status_menus\",\"value\":\"0_COMP_OPTION\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Changestatus_COMP",LR_AUTO);

	lr_start_transaction("Clkok_COMP");

	web_add_header("xhrseqnum", 
		"40");

	lr_think_time(17);

	web_submit_data("maximo.jsp_41", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t199.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7232", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7232\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"41");

	web_submit_data("maximo.jsp_42", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t200.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7232", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"42");

	web_submit_data("maximo.jsp_43", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t201.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7232", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"43");

	web_submit_data("maximo.jsp_44", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t202.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7232", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"44");

	web_submit_data("maximo.jsp_45", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t203.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7232", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_add_header("xhrseqnum", 
		"45");

	web_submit_data("maximo.jsp_46", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t204.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7232", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"longopcheck\",\"targetId\":\"longopwait\",\"value\":\"\",\"requestType\":\"SYNC\"}]", ENDITEM, 
		LAST);

	web_url("st_MessageInformation.png", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/st_MessageInformation.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t205.inf", 
		LAST);

	lr_end_transaction("Clkok_COMP",LR_AUTO);

	lr_start_transaction("Closetab");

	web_add_header("xhrseqnum", 
		"46");

	lr_think_time(19);

	web_submit_data("maximo.jsp_47", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t206.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx7288", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx7288\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	lr_end_transaction("Closetab",LR_AUTO);

	lr_start_transaction("ClkonWO");

	web_add_header("xhrseqnum", 
		"47");

	lr_think_time(18);

	web_submit_data("maximo.jsp_48", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t207.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx2576", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx279\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_url("cb_checkedreadonly.gif", 
		"URL=http://porud755/maximo/webclient/skins-20170809-1350/tivoli09/images/cb_checkedreadonly.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t208.inf", 
		LAST);

	lr_end_transaction("ClkonWO",LR_AUTO);

	lr_start_transaction("Logout");

	web_add_header("xhrseqnum", 
		"48");

	lr_think_time(11);

	web_submit_data("maximo.jsp_49", 
		"Action=http://porud755/maximo/ui/maximo.jsp", 
		"Method=POST", 
		"RecContentType=text/xml", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t209.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=uisessionid", "Value=162", ENDITEM, 
		"Name=csrftoken", "Value=48l0rj1i5tuo54rq9mtv1osq99", ENDITEM, 
		"Name=currentfocus", "Value=mx57", ENDITEM, 
		"Name=scrollleftpos", "Value=0", ENDITEM, 
		"Name=scrolltoppos", "Value=0", ENDITEM, 
		"Name=requesttype", "Value=SYNC", ENDITEM, 
		"Name=responsetype", "Value=text/xml", ENDITEM, 
		"Name=events", "Value=[{\"type\":\"click\",\"targetId\":\"mx57\",\"value\":\"\",\"requestType\":\"SYNC\",\"csrftokenholder\":\"48l0rj1i5tuo54rq9mtv1osq99\"}]", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("_QM_Try");

	web_revert_auto_header("pageseqnum");

	web_url("logout.jsp", 
		"URL=http://porud755/maximo/webclient/login/logout.jsp?uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://porud755/maximo/ui/?event=loadapp&value=emgwotrack&uisessionid=162&csrftoken=48l0rj1i5tuo54rq9mtv1osq99", 
		"Snapshot=t210.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	return 0;
}