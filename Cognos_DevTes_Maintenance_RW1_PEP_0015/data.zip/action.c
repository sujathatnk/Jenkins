Action()
{

	web_url("cognos.cgi", 
		"URL=http://cognos.sgndevtest.com/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../ps/login/images/login_header.png", "Referer=http://cognos.sgndevtest.com/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/login/images/login_ibm_logo.png", "Referer=http://cognos.sgndevtest.com/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		"Url=../ps/login/images/login_icon.png", "Referer=http://cognos.sgndevtest.com/ibmcognos/cgi-bin/cognos.cgi?m_folder=i64C1B8968BDC4C70B18C3DC1286D7E20&m_tab=i64C1B8968BDC4C70B18C3DC1286D7E20&b_action=xts.run&encoding=UTF-8&m=portal%2fcc.xts&m_folder2=m-i937E6052F9724D988EF69846A3CD4D2F", ENDITEM, 
		LAST);

	return 0;
}